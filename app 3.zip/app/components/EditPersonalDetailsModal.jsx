import React, { useState, useEffect } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert
} from 'react-native';
import { savePersonalDetails } from '../services/firebaseService';
import Icon from "react-native-vector-icons/Feather";
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from "expo-speech-recognition";

const EditPersonalDetailsModal = ({ visible, onClose, currentDetails, onSave }) => {
  const [formData, setFormData] = useState({
    name: currentDetails?.name || '',
    contactNo: currentDetails?.contactNo || '',
    address: currentDetails?.address || '',
    email: currentDetails?.email || '',
    dateOfBirth: currentDetails?.dateOfBirth || '',
    emergencyContact: currentDetails?.emergencyContact || '',
    bloodGroup: currentDetails?.bloodGroup || '',
    medicalConditions: currentDetails?.medicalConditions || '',
    allergies: currentDetails?.allergies || '',
    medications: currentDetails?.medications || '',
  });
  const [loading, setLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recognizing, setRecognizing] = useState(false);
  const [currentField, setCurrentField] = useState(null);

  useEffect(() => {
    if (currentDetails) {
      setFormData(currentDetails);
    }
  }, [currentDetails]);

  // Speech recognition setup
  useSpeechRecognitionEvent("start", () => setRecognizing(true));
  useSpeechRecognitionEvent("end", () => {
    setRecognizing(false);
    setIsRecording(false);
  });
  useSpeechRecognitionEvent("result", (event) => {
    const transcript = event.results[0].transcript;
    if (currentField) {
      updateField(currentField, transcript);
    }
    if (event.isFinal) {
      stopVoiceRecognition();
    }
  });
  useSpeechRecognitionEvent("error", (event) => {
    Alert.alert("Error", "Voice recognition failed");
    setIsRecording(false);
    setRecognizing(false);
  });

  useEffect(() => {
    // Request permissions when component mounts
    (async () => {
      const result = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if (!result.granted) {
        console.warn("Permissions not granted", result);
      }
    })();

    return () => {
      if (isRecording) {
        stopVoiceRecognition();
      }
    };
  }, []);

  const startVoiceRecognition = async (field) => {
    try {
      setCurrentField(field);
      setIsRecording(true);
      await ExpoSpeechRecognitionModule.start({
        lang: "en-US",
        interimResults: true,
        continuous: true,
      });
    } catch (error) {
      console.error('Error starting speech recognition:', error);
      setIsRecording(false);
      Alert.alert('Error', 'Failed to start voice recognition');
    }
  };

  const stopVoiceRecognition = async () => {
    try {
      await ExpoSpeechRecognitionModule.stop();
      setIsRecording(false);
    } catch (error) {
      console.error('Error stopping speech recognition:', error);
    }
  };

  const handleVoiceInput = (field) => {
    if (isRecording && currentField === field) {
      stopVoiceRecognition();
    } else {
      if (isRecording) {
        stopVoiceRecognition().then(() => startVoiceRecognition(field));
      } else {
        startVoiceRecognition(field);
      }
    }
  };

  const handleSave = async () => {
    try {
      setLoading(true);
      const filteredData = {};
      Object.keys(formData).forEach(key => {
        const value = formData[key];
        if (value !== undefined && value !== null && typeof value === 'string') {
          const trimmedValue = value.trim();
          if (trimmedValue !== '') {
            filteredData[key] = trimmedValue;
          }
        } else if (value !== undefined && value !== null) {
          filteredData[key] = value;
        }
      });

      await savePersonalDetails(filteredData);
      onSave(filteredData);
      onClose();
    } catch (error) {
      console.error('Error saving personal details:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose}>
            <Text style={styles.cancelButton}>Cancel</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Edit Personal Details</Text>
          <TouchableOpacity onPress={handleSave} disabled={loading}>
            <Text style={[styles.saveButton, loading && styles.disabledButton]}>
              {loading ? 'Saving...' : 'Save'}
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Name</Text>
            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                value={formData.name}
                onChangeText={(value) => updateField('name', value)}
                placeholder="Enter your name"
              />
              <TouchableOpacity
                style={[styles.voiceButton, isRecording && currentField === 'name' && styles.recordingButton]}
                onPress={() => handleVoiceInput('name')}
              >
                <Icon
                  name={isRecording && currentField === 'name' ? 'mic-off' : 'mic'}
                  size={20}
                  color={isRecording && currentField === 'name' ? '#E63946' : '#6B705B'}
                />
                {recognizing && currentField === 'name' && (
                  <View style={styles.recordingIndicator} />
                )}
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Contact Number</Text>
            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                value={formData.contactNo}
                onChangeText={(value) => updateField('contactNo', value)}
                placeholder="Enter contact number"
                keyboardType="phone-pad"
              />
              <TouchableOpacity
                style={[styles.voiceButton, isRecording && currentField === 'contactNo' && styles.recordingButton]}
                onPress={() => handleVoiceInput('contactNo')}
              >
                <Icon
                  name={isRecording && currentField === 'contactNo' ? 'mic-off' : 'mic'}
                  size={20}
                  color={isRecording && currentField === 'contactNo' ? '#E63946' : '#6B705B'}
                />
                {recognizing && currentField === 'contactNo' && (
                  <View style={styles.recordingIndicator} />
                )}
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Address</Text>
            <View style={styles.inputRow}>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={formData.address}
                onChangeText={(value) => updateField('address', value)}
                placeholder="Enter your address"
                multiline
                numberOfLines={3}
              />
              <TouchableOpacity
                style={[styles.voiceButton, isRecording && currentField === 'address' && styles.recordingButton]}
                onPress={() => handleVoiceInput('address')}
              >
                <Icon
                  name={isRecording && currentField === 'address' ? 'mic-off' : 'mic'}
                  size={20}
                  color={isRecording && currentField === 'address' ? '#E63946' : '#6B705B'}
                />
                {recognizing && currentField === 'address' && (
                  <View style={styles.recordingIndicator} />
                )}
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Blood Group</Text>
            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                value={formData.bloodGroup}
                onChangeText={(value) => updateField('bloodGroup', value)}
                placeholder="e.g., O+, A-, B+"
              />
              <TouchableOpacity
                style={[styles.voiceButton, isRecording && currentField === 'bloodGroup' && styles.recordingButton]}
                onPress={() => handleVoiceInput('bloodGroup')}
              >
                <Icon
                  name={isRecording && currentField === 'bloodGroup' ? 'mic-off' : 'mic'}
                  size={20}
                  color={isRecording && currentField === 'bloodGroup' ? '#E63946' : '#6B705B'}
                />
                {recognizing && currentField === 'bloodGroup' && (
                  <View style={styles.recordingIndicator} />
                )}
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#22577A',
  },
  cancelButton: {
    color: '#666',
    fontSize: 16,
  },
  saveButton: {
    color: '#22577A',
    fontSize: 16,
    fontWeight: 'bold',
  },
  disabledButton: {
    opacity: 0.5,
  },
  form: {
    flex: 1,
    padding: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#22577A',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
    width: '85%'
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    gap: 8,
  },
  voiceButton: {
    padding: 10,
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E9E9E0',
    position: 'relative',
    width: '15%',
    justifyContent: 'center',
    alignItems: 'center'
  },
  recordingButton: {
    backgroundColor: '#FFE5E7',
    borderColor: '#E63946',
  },
  recordingIndicator: {
    position: 'absolute',
    top: 2,
    right: 2,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#E63946',
  },
});

export default EditPersonalDetailsModal;
