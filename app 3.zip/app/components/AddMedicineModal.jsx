import React, { useState, useEffect } from 'react';
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  TextInput,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { firestore } from '../config/firebase';
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from "expo-speech-recognition";
import { schedulePushNotification, cancelScheduledNotification } from '../utils/notificationUtils'; // Adjust the import path as necessary

const AddMedicineModal = ({ visible, onClose, onMedicineAdded, editingMedicine = null, showSuccessAlert, showErrorAlert, notificationsEnabled }) => {
  const [formData, setFormData] = useState({
    name: editingMedicine?.name || '',
    dosage: editingMedicine?.dosage || '',
    frequency: editingMedicine?.frequency || '',
    timeToTake: editingMedicine?.timeToTake || '',
    refillDate: editingMedicine?.refillDate || ''
  });
  const [loading, setLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recognizing, setRecognizing] = useState(false);
  const [currentField, setCurrentField] = useState(null);

  const auth = getAuth();
  const user = auth.currentUser;

  // In AddMedicineModal component
useEffect(() => {
  if (editingMedicine) {
    setFormData({
      name: editingMedicine.name || '',
      dosage: editingMedicine.dosage || '',
      frequency: editingMedicine.frequency || '',
      timeToTake: editingMedicine.timeToTake || '',
      refillDate: editingMedicine.refillDate || ''
    });
  } else {
    setFormData({
      name: '',
      dosage: '',
      frequency: '',
      timeToTake: '',
      refillDate: ''
    });
  }
}, [editingMedicine, visible]); // Add visible to dependencies
  
  useSpeechRecognitionEvent("start", () => setRecognizing(true));
  useSpeechRecognitionEvent("end", () => {
    setRecognizing(false);
    setIsRecording(false);
  });
  useSpeechRecognitionEvent("result", (event) => {
    console.warn("Speech recognition result:", event);
      // Get the most confident result
      const transcript = event.results[0].transcript;
      console.warn("currentField==>>> ", currentField);
      
      if (currentField) {
        handleInputChange(currentField, transcript);
        console.log(`Recognized text for ${currentField}:`, transcript);
      }
      
      // Optional: Stop recording after getting the result if isFinal is true
      if (event.isFinal) {
        stopVoiceRecognition();
      }
  })
  useSpeechRecognitionEvent("error", (event) => {
    console.log("error code:", event.error, "error message:", event.message);
    Alert.alert("Error", "Voice recognition failed");
    setIsRecording(false);
    setRecognizing(false);
  });

  useEffect(() => {
    // Request permissions when component mounts
    (async () => {
      const result = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if (!result.granted) {
        console.warn("Permissions not granted", result);
        return;
      }
    })();

    return () => {
      if (isRecording) {
        stopVoiceRecognition();
      }
    };
  }, []);

  const startVoiceRecognition = async (field) => {
    try {
      setCurrentField(field);
      setIsRecording(true);
      await ExpoSpeechRecognitionModule.start({
        lang: "en-US",
        interimResults: true,
        continuous: true,
      });
    } catch (error) {
      console.error('Error starting speech recognition:', error);
      setIsRecording(false);
      Alert.alert('Error', 'Failed to start voice recognition');
    }
  };

  const stopVoiceRecognition = async () => {
    try {
      await ExpoSpeechRecognitionModule.stop();
      setIsRecording(false);
    } catch (error) {
      console.error('Error stopping speech recognition:', error);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleVoiceInput = (field) => {
    if (isRecording && currentField === field) {
      stopVoiceRecognition();
    } else {
      if (isRecording) {
        stopVoiceRecognition().then(() => startVoiceRecognition(field));
      } else {
        startVoiceRecognition(field);
      }
    }
  };

  const validateForm = () => {
    if (!formData.name.trim()) {
      Alert.alert('Error', 'Please enter medicine name');
      return false;
    }
    if (!formData.dosage.trim()) {
      Alert.alert('Error', 'Please enter dosage');
      return false;
    }
    if (!formData.frequency.trim()) {
      Alert.alert('Error', 'Please enter frequency');
      return false;
    }
    if (!formData.timeToTake.trim()) {
      Alert.alert('Error', 'Please enter time to take');
      return false;
    }
    if (!formData.refillDate.trim()) {
      Alert.alert('Error', 'Please enter refill date');
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    if (!user) {
      Alert.alert('Error', 'Please login to add medicines');
      return;
    }

    setLoading(true);
    try {
      const medicineData = {
        ...formData,
        userId: user.uid,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      if (editingMedicine) {
        // Update existing medicine
        const medicineRef = doc(firestore, 'medicines', editingMedicine.id);
        await updateDoc(medicineRef, {
          ...formData,
          updatedAt: new Date().toISOString()
        });
        await cancelScheduledNotification(editingMedicine.id);
        if (notificationsEnabled) {
          await schedulePushNotification(
            editingMedicine.id,
            `Time to take ${formData.name}`,
            `It's time to take your ${formData.name} (${formData.dosage})`,
            formData.timeToTake
          );
        }
        if (showSuccessAlert) {
          showSuccessAlert('Medicine updated successfully!');
        } else {
          Alert.alert('Success', 'Medicine updated successfully!');
        }
      } else {
        // Add new medicine
        const docRef = await addDoc(collection(firestore, 'medicines'), medicineData);
          // Schedule notification if enabled
          if (notificationsEnabled) {
            await schedulePushNotification(
              docRef.id,
              `Time to take ${formData.name}`,
              `It's time to take your ${formData.name} (${formData.dosage})`,
              formData.timeToTake
            );
          }
          
        if (showSuccessAlert) {
          showSuccessAlert('Medicine added successfully!');
        } else {
          Alert.alert('Success', 'Medicine added successfully!');
        }
      }

      onMedicineAdded();
      handleClose();
    } catch (error) {
      console.error('Error saving medicine:', error);
      if (showErrorAlert) {
        showErrorAlert('Failed to save medicine. Please try again.');
      } else {
        Alert.alert('Error', 'Failed to save medicine. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (isRecording) {
      stopVoiceRecognition();
    }
    setFormData({
      name: '',
      dosage: '',
      frequency: '',
      timeToTake: '',
      refillDate: ''
    });
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={handleClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Header */}
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {editingMedicine ? 'Edit Medicine' : 'Add Medicine'}
              </Text>
              <TouchableOpacity onPress={handleClose} style={styles.closeButton}>
                <Icon name="x" size={24} color="#6B705B" />
              </TouchableOpacity>
            </View>

            {/* Form Fields */}
            <View style={styles.formContainer}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Medicine Name *</Text>
                <View style={styles.inputRow}>
                  <TextInput
                    style={[styles.textInput, { flex: 1 }]}
                    value={formData.name}
                    onChangeText={(text) => handleInputChange('name', text)}
                    placeholder="Enter medicine name"
                    placeholderTextColor="#999"
                  />
                  <TouchableOpacity 
                    style={[styles.voiceButton, isRecording && currentField === 'name' && styles.recordingButton]}
                    onPress={() => handleVoiceInput('name')}
                  >
                    <Icon 
                      name={isRecording && currentField === 'name' ? 'mic-off' : 'mic'} 
                      size={20} 
                      color={isRecording && currentField === 'name' ? '#E63946' : '#6B705B'} 
                    />
                    {recognizing && currentField === 'name' && (
                      <View style={styles.recordingIndicator} />
                    )}
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Dosage *</Text>
                <View style={styles.inputRow}>
                  <TextInput
                    style={[styles.textInput, { flex: 1 }]}
                    value={formData.dosage}
                    onChangeText={(text) => handleInputChange('dosage', text)}
                    placeholder="e.g., 500mg, 1 tablet"
                    placeholderTextColor="#999"
                  />
                  <TouchableOpacity 
                    style={[styles.voiceButton, isRecording && currentField === 'dosage' && styles.recordingButton]}
                    onPress={() => handleVoiceInput('dosage')}
                  >
                    <Icon 
                      name={isRecording && currentField === 'dosage' ? 'mic-off' : 'mic'} 
                      size={20} 
                      color={isRecording && currentField === 'dosage' ? '#E63946' : '#6B705B'} 
                    />
                    {recognizing && currentField === 'dosage' && (
                      <View style={styles.recordingIndicator} />
                    )}
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Frequency *</Text>
                <View style={styles.inputRow}>
                  <TextInput
                    style={[styles.textInput, { flex: 1 }]}
                    value={formData.frequency}
                    onChangeText={(text) => handleInputChange('frequency', text)}
                    placeholder="e.g., 2 times per day"
                    placeholderTextColor="#999"
                  />
                  <TouchableOpacity 
                    style={[styles.voiceButton, isRecording && currentField === 'frequency' && styles.recordingButton]}
                    onPress={() => handleVoiceInput('frequency')}
                  >
                    <Icon 
                      name={isRecording && currentField === 'frequency' ? 'mic-off' : 'mic'} 
                      size={20} 
                      color={isRecording && currentField === 'frequency' ? '#E63946' : '#6B705B'} 
                    />
                    {recognizing && currentField === 'frequency' && (
                      <View style={styles.recordingIndicator} />
                    )}
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Time to Take *</Text>
                <View style={styles.inputRow}>
                  <TextInput
                    style={[styles.textInput, { flex: 1 }]}
                    value={formData.timeToTake}
                    onChangeText={(text) => handleInputChange('timeToTake', text)}
                    placeholder="e.g., 9:00 AM, 2:00 PM"
                    placeholderTextColor="#999"
                  />
                  <TouchableOpacity 
                    style={[styles.voiceButton, isRecording && currentField === 'timeToTake' && styles.recordingButton]}
                    onPress={() => handleVoiceInput('timeToTake')}
                  >
                    <Icon 
                      name={isRecording && currentField === 'timeToTake' ? 'mic-off' : 'mic'} 
                      size={20} 
                      color={isRecording && currentField === 'timeToTake' ? '#E63946' : '#6B705B'} 
                    />
                    {recognizing && currentField === 'timeToTake' && (
                      <View style={styles.recordingIndicator} />
                    )}
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Refill Date *</Text>
                <View style={styles.inputRow}>
                  <TextInput
                    style={[styles.textInput, { flex: 1 }]}
                    value={formData.refillDate}
                    onChangeText={(text) => handleInputChange('refillDate', text)}
                    placeholder="DD/MM/YYYY"
                    placeholderTextColor="#999"
                  />
                  <TouchableOpacity 
                    style={[styles.voiceButton, isRecording && currentField === 'refillDate' && styles.recordingButton]}
                    onPress={() => handleVoiceInput('refillDate')}
                  >
                    <Icon 
                      name={isRecording && currentField === 'refillDate' ? 'mic-off' : 'mic'} 
                      size={20} 
                      color={isRecording && currentField === 'refillDate' ? '#E63946' : '#6B705B'} 
                    />
                    {recognizing && currentField === 'refillDate' && (
                      <View style={styles.recordingIndicator} />
                    )}
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            {/* Action Buttons */}
            <View style={styles.buttonContainer}>
              <TouchableOpacity 
                style={[styles.submitButton, loading && styles.disabledButton]} 
                onPress={handleSubmit}
                disabled={loading}
              >
                <Icon name="check" size={18} color="#fff" />
                <Text style={styles.submitButtonText}>
                  {loading ? 'Saving...' : (editingMedicine ? 'Update' : 'Submit')}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.cancelButton} onPress={handleClose}>
                <Icon name="x" size={18} color="#6B705B" />
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    width: '90%',
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#6B705B',
  },
  closeButton: {
    padding: 5,
  },
  formContainer: {
    marginBottom: 30,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#24507A',
    marginBottom: 8,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E9E9E0',
    borderRadius: 12,
    padding: 15,
    fontSize: 16,
    color: '#495057',
    backgroundColor: '#F8F9FA',
  },
  voiceButton: {
    padding: 10,
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E9E9E0',
    position: 'relative',
  },
  recordingButton: {
    backgroundColor: '#FFE5E7',
    borderColor: '#E63946',
  },
  recordingIndicator: {
    position: 'absolute',
    top: 2,
    right: 2,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#E63946',
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 15,
  },
  submitButton: {
    flex: 1,
    backgroundColor: '#6B705B',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  disabledButton: {
    backgroundColor: '#ccc',
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: '#E9E9E0',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6B705B',
  },
});

export default AddMedicineModal;