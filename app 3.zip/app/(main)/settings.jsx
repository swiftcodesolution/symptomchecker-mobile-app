import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Switch } from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AnimatedBackground from '../components/AnimatedBackground';
import Header from '../components/Header';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState } from 'react';

const profileImg = require('../../assets/user.jpg');

const Settings = () => {
  const { theme } = useTheme();
  const navigation = useNavigation();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [locationServices, setLocationServices] = useState(true);
  const [expandedInfo, setExpandedInfo] = useState(null);

  const infoContents = {
    4: 'We value your privacy. Your data is securely stored and never shared with third parties without your consent. Read our full privacy policy for more details.',
    5: 'By using this app, you agree to our terms of service. Please review them carefully to understand your rights and responsibilities.',
    6: 'Symptom Checker AI\nVersion 1.0.0\nThis app helps you track symptoms, manage medications, and access health resources. For support, contact us anytime.'
  };

  const settingsItems = [
    {
      id: 1,
      title: 'Notifications',
      subtitle: 'Enable push notifications',
      icon: 'notifications-outline',
      type: 'switch',
      value: notifications,
      onValueChange: setNotifications,
    },
    // {
    //   id: 2,
    //   title: 'Dark Mode',
    //   subtitle: 'Switch to dark theme',
    //   icon: 'moon-outline',
    //   type: 'switch',
    //   value: darkMode,
    //   onValueChange: setDarkMode,
    // },
    {
      id: 3,
      title: 'Location Services',
      subtitle: 'Allow location access',
      icon: 'location-outline',
      type: 'switch',
      value: locationServices,
      onValueChange: setLocationServices,
    },
    {
      id: 4,
      title: 'Privacy Policy',
      subtitle: 'Read our privacy policy',
      icon: 'shield-checkmark-outline',
      type: 'info',
    },
    {
      id: 5,
      title: 'Terms of Service',
      subtitle: 'Read our terms of service',
      icon: 'document-text-outline',
      type: 'info',
    },
    {
      id: 6,
      title: 'About App',
      subtitle: 'Version 1.0.0',
      icon: 'information-circle-outline',
      type: 'info',
    },
  ];

  const toggleInfo = (id) => {
    setExpandedInfo(expandedInfo === id ? null : id);
  };

  return (
    <AnimatedBackground>
      <SafeAreaView style={{ flex: 1 }}>
        <Header
          profileImage={profileImg}
          greeting="Hello Scott"
          location="SC, 702 USA"
          sos={true}
        />
        
        <ScrollView 
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.title}>Settings</Text>
          
          <View style={styles.contentSection}>
            <View style={styles.settingsList}>
              {settingsItems.map((item) => (
                <View key={item.id} style={{ width: '100%' }}>
                  <View style={styles.settingCard}>
                    <View style={styles.settingLeft}>
                      <Ionicons 
                        name={item.icon} 
                        size={24} 
                        color={theme.primary} 
                        style={styles.settingIcon} 
                      />
                      <View style={styles.settingText}>
                        <Text style={styles.settingTitle}>{item.title}</Text>
                        <Text style={styles.settingSubtitle}>{item.subtitle}</Text>
                      </View>
                    </View>
                    {item.type === 'switch' ? (
                      <Switch
                        value={item.value}
                        onValueChange={item.onValueChange}
                        trackColor={{ false: '#767577', true: theme.primary }}
                        thumbColor={item.value ? '#f4f3f4' : '#f4f3f4'}
                      />
                    ) : item.type === 'info' ? (
                      <TouchableOpacity style={styles.linkButton} onPress={() => toggleInfo(item.id)}>
                        <Ionicons name={expandedInfo === item.id ? 'chevron-up' : 'chevron-down'} size={20} color={theme.primary} />
                      </TouchableOpacity>
                    ) : (
                      <TouchableOpacity style={styles.linkButton}>
                        <Ionicons name="chevron-forward" size={20} color={theme.primary} />
                      </TouchableOpacity>
                    )}
                  </View>
                  {item.type === 'info' && expandedInfo === item.id && (
                    <View style={styles.infoContent}>
                      <Text style={styles.infoText}>{infoContents[item.id]}</Text>
                    </View>
                  )}
                </View>
              ))}
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default Settings;

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  title: {
    fontSize: 36,
    color: '#4d5a5a',
    textAlign: 'center',
    fontWeight: '400',
    marginBottom: 18,
  },
  contentSection: {
    paddingHorizontal: 18,
  },
  settingsList: {
    width: '100%',
    alignItems: 'center',
    gap: 12,
  },
  settingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#d3cdc3',
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 18,
    width: '100%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    marginRight: 12,
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 18,
    color: '#222',
    fontWeight: '600',
    marginBottom: 2,
  },
  settingSubtitle: {
    fontSize: 14,
    color: '#666',
    fontWeight: '400',
  },
  linkButton: {
    padding: 8,
  },
  infoContent: {
    backgroundColor: '#ede8e0',
    borderRadius: 12,
    marginTop: -8,
    marginBottom: 12,
    paddingHorizontal: 18,
    paddingVertical: 12,
    width: '100%',
  },
  infoText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
}); 