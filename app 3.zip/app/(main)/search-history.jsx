import { FlatList, StyleSheet, View, Image, Text, TouchableOpacity, Animated, Easing } from "react-native";
import { useTheme } from "../theme/ThemeContext";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader from "../components/CustomHeader";
import TitleText from "../components/TitleText";
import PrimaryButton from "../components/PrimaryButton";
import SearchHistoryCard from "../components/SearchHistoryCard";
import Searchbar from "../components/Searchbar";
import AnimatedBackground from "../components/AnimatedBackground";
import { useState, useRef, useEffect } from "react";
import { useNavigation } from '@react-navigation/native';
import Header from "../components/Header";

const profileImg = require("../../assets/user.jpg");

const searchHistory = [
  {
    id: "1",
    text: "A crucial first aid tip is to ensure your own safety before approaching the injured. Read More",
    date: "25th May, 2025",
    time: "9:30 PM",
  },
  {
    id: "2",
    text: "CPR can save lives in emergencies — remember the steps: Check, Call, Compress. Read More",
    date: "24th May, 2025",
    time: "11:00 AM",
  },
  {
    id: "3",
    text: "Keep a basic first aid kit at home, in your car, and at work. Read More",
    date: "23rd May, 2025",
    time: "6:15 PM",
  },
  {
    id: "4",
    text: "Learn how to treat burns and cuts to avoid infection. Read More",
    date: "22nd May, 2025",
    time: "2:45 PM",
  },
  {
    id: "5",
    text: "In case of choking, the Heimlich maneuver can be life-saving. Read More",
    date: "21st May, 2025",
    time: "10:00 AM",
  },
  {
    id: "6",
    text: "Stay calm and assess the situation before giving first aid. Read More",
    date: "20th May, 2025",
    time: "8:20 AM",
  },
  {
    id: "7",
    text: "Know the difference between a heart attack and cardiac arrest. Read More",
    date: "19th May, 2025",
    time: "4:30 PM",
  },
  {
    id: "8",
    text: "Apply pressure to stop bleeding until help arrives. Read More",
    date: "18th May, 2025",
    time: "7:50 PM",
  },
  {
    id: "9",
    text: "Always wash your hands before and after treating wounds. Read More",
    date: "17th May, 2025",
    time: "1:10 PM",
  },
  {
    id: "10",
    text: "Use cold compresses to reduce swelling after minor injuries. Read More",
    date: "16th May, 2025",
    time: "9:00 AM",
  },
];

const HEADER_HEIGHT = 550; // Adjust as needed for your header

const SearchHistory = () => {
  const { theme } = useTheme();
  const [activeTab, setActiveTab] = useState("Recent");
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const lastScrollY = useRef(0);
  const anim = useRef(new Animated.Value(0)).current; // 0: visible, -HEADER_HEIGHT: hidden
  const navigation = useNavigation();

  const handlePress = (tab) => setActiveTab(tab);

  // Animate header in/out
  const animateHeader = (show) => {
    Animated.timing(anim, {
      toValue: show ? 0 : -HEADER_HEIGHT,
      duration: 350,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  };

  // Scroll handler
  const handleScroll = (event) => {
    const currentY = event.nativeEvent.contentOffset.y;
    const delta = currentY - lastScrollY.current;

    if (Math.abs(delta) < 10) return; // Ignore small scrolls

    if (delta > 0 && isHeaderVisible && currentY > 40) {
      setIsHeaderVisible(false);
      animateHeader(false);
    } else if (delta < 0 && !isHeaderVisible && currentY < 60) {
      setIsHeaderVisible(true);
      animateHeader(true);
    }
    lastScrollY.current = currentY;
  };

  return (
    <AnimatedBackground>
      <SafeAreaView style={{ flex: 1 }}>

        <View style={styles.contentSection}>
          {/* Animated Header/Search/Toggle - absolutely positioned */}
          <Animated.View
            style={[
              styles.animatedContent,
              {
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                marginLeft:"5%",
                transform: [{ translateY: anim }],
                opacity: anim.interpolate({
                  inputRange: [-HEADER_HEIGHT, 0],
                  outputRange: [0, 1],
                }),
              },
            ]}
          >
            <Header
              profileImage={profileImg}
              greeting="Hello Scott"
              location="SC, 702 USA"
              sos={true}
            />
            {/* Title */}
            <Text style={styles.pageTitle}>Symptom checker{"\n"}chat History</Text>
            {/* Search Bar */}
            <View style={styles.searchBarContainer}>
              <Searchbar placeholder="Search your chat" style={{ borderRadius: 24, backgroundColor: "#D3D3C3AA" }} />
            </View>
            {/* Toggle Buttons */}
            <View style={styles.toggleButtons}>
              <TouchableOpacity onPress={() => handlePress("Recent")}
                style={[styles.toggleBtn, activeTab === "Recent" && styles.activeToggleBtn]}>
                <Text style={styles.toggleText}>Recent</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handlePress("Last")}
                style={[styles.toggleBtn, activeTab === "Last" && styles.activeToggleBtn]}>
                <Text style={styles.toggleText}>Last</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
          {/* List */}
          <View style={styles.listWrapper}>
            <FlatList
              data={searchHistory}
              keyExtractor={(item) => item.id}
              renderItem={({ item, index }) => (
                <View style={[styles.historyCard, index === 0 && { marginTop: HEADER_HEIGHT }]}>
                  <Text style={styles.cardText}>{item.text}</Text>
                  <Text style={styles.cardDate}>{item.date}{"\n"}{item.time}</Text>
                </View>
              )}
              onScroll={handleScroll}
              scrollEventThrottle={16}
              contentContainerStyle={styles.listContainer}
              showsVerticalScrollIndicator={false}
              style={styles.flatList}
            />
          </View>
        </View>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default SearchHistory;

const styles = StyleSheet.create({
  contentSection: {
    paddingHorizontal: 18,
    flex: 1,
  },
  pageTitle: {
    fontSize: 36,
    color: '#4d5a5a',
    textAlign: "center",
    fontWeight: "300",
    marginBottom: 10,
  },
  searchBarContainer: {
    marginBottom: 18,
  },
  toggleButtons: {
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 18,
    gap: 10,
  },
  toggleBtn: {
    flex: 1,
    backgroundColor: "#C7CBD6",
    borderRadius: 32,
    paddingVertical: 18,
    alignItems: "center",
  },
  activeToggleBtn: {
    backgroundColor: "#7B8263",
  },
  toggleText: {
    color: "#fff",
    fontSize: 22,
    fontWeight: "400",
  },
  historyCard: {
    backgroundColor: "#C7CBD6",
    borderRadius: 24,
    padding: 22,
    marginBottom: 14,
  },
  cardText: {
    color: "#fff",
    fontSize: 20,
    marginBottom: 10,
  },
  cardDate: {
    color: "#3B4A5A",
    fontSize: 16,
    textAlign: "right",
  },
  listContainer: {
    paddingBottom: 30,
  },
  hiddenIndicator: {
    backgroundColor: "#7B8263",
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    alignItems: "center",
  },
  hiddenText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "500",
    textAlign: "center",
  },
  animatedContent: {
    zIndex: 1,
    backgroundColor: 'transparent',
    width: '100%',
  },
  flatList: {
    // marginTop:400,
    flex: 1,
  },
  listWrapper: {
    flex: 1,
  },
});
