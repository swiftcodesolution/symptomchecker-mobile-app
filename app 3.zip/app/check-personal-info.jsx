import { useEffect } from "react";
import { View, Image, Text, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function CheckPersonalInfo() {
  const router = useRouter();

  useEffect(() => {
    const checkPersonalInfo = async () => {
      try {
        const personalInfo = await AsyncStorage.getItem('personalInfo');
        if (personalInfo) {
          router.replace("/(main)");
        } else {
          router.replace("/collect-user-info");
        }
      } catch (error) {
        console.error('Error checking personal info:', error);
        router.replace("/collect-user-info");
      }
    };

    checkPersonalInfo();
  }, []);

  return (
    <View style={styles.container}>
      <Image source={require("../assets/logo.png")} style={styles.logo} />
      <Text style={styles.text}>Loading...</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#9CA090",
  },
  logo: {
    width: 120,
    height: 120,
    marginBottom: 32,
    resizeMode: "contain",
  },
  text: {
    fontSize: 26,
    color: "#fff",
    fontWeight: "400",
    textAlign: "center",
  },
}); 