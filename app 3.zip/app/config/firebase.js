import { initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { GoogleSignin } from '@react-native-google-signin/google-signin';

// Firebase configuration for React Native
const firebaseConfig = {
  apiKey: "AIzaSyBmEQNyMOt6rBr6R-cC8XbV-TRO1i8-x90",
  authDomain: "ai-boat-341cf.firebaseapp.com",
  projectId: "ai-boat-341cf",
  storageBucket: "ai-boat-341cf.firebasestorage.app",
  messagingSenderId: "749534211951",
  appId: "1:749534211951:android:cfdd80fe6db9de4e2c829a"
};

console.log('Firebase config:', firebaseConfig);

// Initialize Firebase
let app = null;
let firebaseAuth = null;

try {
  console.log('Initializing Firebase...');
  app = initializeApp(firebaseConfig);
  console.log('Firebase app initialized successfully');

  // Initialize Auth with persistence for React Native
  try {
    firebaseAuth = initializeAuth(app, {
      persistence: getReactNativePersistence(AsyncStorage)
    });
    console.log('Firebase Auth initialized with persistence');
  } catch (authError) {
    console.log('Failed to initialize Auth with persistence, using fallback:', authError);
    firebaseAuth = getAuth(app);
    console.log('Firebase Auth initialized without persistence');
  }

  // Test if auth is working
  if (firebaseAuth) {
    console.log('Firebase Auth is ready to use');
  } else {
    console.error('Firebase Auth is null after initialization');
  }
} catch (error) {
  console.error('Firebase initialization error:', error);
  console.error('Error details:', error.message);
}

// Initialize Firestore
let firestore = null;
try {
  firestore = getFirestore(app);
  console.log('Firestore initialized successfully');
} catch (error) {
  console.error('Firestore initialization error:', error);
}

// Configure Google Sign-In with your actual Web Client ID
const configureGoogleSignIn = () => {
  try {
    console.log('Configuring Google Sign-In...');
    
    if (!GoogleSignin) {
      console.error('GoogleSignin is not available');
      return;
    }

    // Your actual Web Client ID from google-services.json
    const webClientId = '828628024879-f1b8q4eq8lqsagt0kkroe8mvcuue1vgn.apps.googleusercontent.com';
    
    GoogleSignin.configure({
      webClientId: webClientId,
      offlineAccess: true,
    });

    console.log('✅ Google Sign-In configured successfully with webClientId:', webClientId);

    // Test Google Sign-In configuration
    GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true })
      .then((hasPlayServices) => {
        console.log('✅ Google Play Services available:', hasPlayServices);
      })
      .catch((error) => {
        console.error('❌ Google Play Services error:', error);
      });
  } catch (error) {
    console.error('❌ Google Sign-In configuration error:', error);
  }
};

// Initialize Google Sign-In
configureGoogleSignIn();

// Export with null checks
export { app, firebaseAuth, firestore, GoogleSignin };
export default { app, firebaseAuth, firestore, GoogleSignin };
