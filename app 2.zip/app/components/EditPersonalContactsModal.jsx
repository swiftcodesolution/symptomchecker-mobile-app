import React, { useState, useEffect } from 'react';
import {
    Modal,
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    Alert
} from 'react-native';
import { savePersonalContact } from '../services/firebaseService';

const EditPersonalContactsModal = ({ visible, onClose, currentContact, onSave }) => {
    const [formData, setFormData] = useState({
        Name: '',
        Relation: '',
        ContactNumber: '',
    });
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (currentContact) {
            setFormData(currentContact);
        } else {
            // Reset form for new contact
            setFormData({
                Name: '',
                Relation: '',
                ContactNumber: '',
            });
        }
    }, [currentContact]);

    const handleSave = async () => {
        try {
            setLoading(true);

            // Filter out empty fields safely
            const filteredData = {};
            Object.keys(formData).forEach(key => {
                const value = formData[key];

                // Only process if the value exists
                if (value !== undefined && value !== null) {
                    // If it's a string, trim it and only include if not empty
                    if (typeof value === 'string') {
                        const trimmedValue = value.trim();
                        if (trimmedValue !== '') {
                            filteredData[key] = trimmedValue;
                        }
                    } else {
                        // For non-string values (numbers, dates), include as-is
                        filteredData[key] = value;
                    }
                }
            });

            await savePersonalContact(filteredData);
            onSave();
            onClose();
        } catch (error) {
            console.error('Error saving contact:', error);
        } finally {
            setLoading(false);
        }
    };

    const updateField = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    return (
        <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
            <View style={styles.container}>
                <View style={styles.header}>
                    <TouchableOpacity onPress={onClose}>
                        <Text style={styles.cancelButton}>Cancel</Text>
                    </TouchableOpacity>
                    <Text style={styles.title}>
                        {currentContact ? 'Edit Contact' : 'Add Contact'}
                    </Text>
                    <TouchableOpacity onPress={handleSave} disabled={loading}>
                        <Text style={[styles.saveButton, loading && styles.disabledButton]}>
                            {loading ? 'Saving...' : 'Save'}
                        </Text>
                    </TouchableOpacity>
                </View>

                <ScrollView style={styles.form}>
                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Name *</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.Name}
                            onChangeText={(value) => updateField('Name', value)}
                            placeholder="Enter contact name"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Relation *</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.Relation}
                            onChangeText={(value) => updateField('Relation', value)}
                            placeholder="Enter relationship"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Contact Number *</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.ContactNumber}
                            onChangeText={(value) => updateField('ContactNumber', value)}
                            placeholder="Enter phone number"
                            keyboardType="phone-pad"
                        />
                    </View>
                </ScrollView>
            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#e0e0e0',
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#22577A',
    },
    cancelButton: {
        color: '#666',
        fontSize: 16,
    },
    saveButton: {
        color: '#22577A',
        fontSize: 16,
        fontWeight: 'bold',
    },
    disabledButton: {
        opacity: 0.5,
    },
    form: {
        flex: 1,
        padding: 16,
    },
    inputGroup: {
        marginBottom: 16,
    },
    label: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#22577A',
        marginBottom: 8,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 8,
        padding: 12,
        fontSize: 16,
        backgroundColor: '#f9f9f9',
    },
});

export default EditPersonalContactsModal;