import React, { useState, useEffect } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert
} from 'react-native';
import { saveDoctorDetails } from '../services/firebaseService';

const EditDoctorModal = ({ visible, onClose, currentDoctor, onSave }) => {
  const [formData, setFormData] = useState({
    doctorName: '',
    phoneNo: '',
    email: '',
    address: '',
    specialization: '',
    hospitalName: '',
    consultationFee: '',
    notes: ''
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (currentDoctor) {
      setFormData(currentDoctor);
    } else {
      setFormData({
        doctorName: '',
        phoneNo: '',
        email: '',
        address: '',
        specialization: '',
        hospitalName: '',
        consultationFee: '',
        notes: ''
      });
    }
  }, [currentDoctor]);

  const handleSave = async () => {
    if (!formData.doctorName || !formData.phoneNo) {
      Alert.alert('Error', 'Doctor name and phone number are required.');
      return;
    }

    try {
      setLoading(true);

      // Safely filter and trim data
      const filteredData = {};
      Object.keys(formData).forEach(key => {
        const value = formData[key];

        // Only process if the value exists
        if (value !== undefined && value !== null) {
          // If it's a string, trim it and only include if not empty
          if (typeof value === 'string') {
            const trimmedValue = value.trim();
            if (trimmedValue !== '') {
              filteredData[key] = trimmedValue;
            }
          } else {
            // For non-string values (numbers, etc.), include as-is
            filteredData[key] = value;
          }
        }
      });

      await saveDoctorDetails(filteredData);
      onSave();
      onClose();
    } catch (error) {
      console.error('Error saving doctor details:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose}>
            <Text style={styles.cancelButton}>Cancel</Text>
          </TouchableOpacity>
          <Text style={styles.title}>
            {currentDoctor ? 'Edit Doctor' : 'Add Doctor'}
          </Text>
          <TouchableOpacity onPress={handleSave} disabled={loading}>
            <Text style={[styles.saveButton, loading && styles.disabledButton]}>
              {loading ? 'Saving...' : 'Save'}
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Doctor Name *</Text>
            <TextInput
              style={styles.input}
              value={formData.doctorName}
              onChangeText={(value) => updateField('doctorName', value)}
              placeholder="Enter doctor's name"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Phone Number *</Text>
            <TextInput
              style={styles.input}
              value={formData.phoneNo}
              onChangeText={(value) => updateField('phoneNo', value)}
              placeholder="Enter phone number"
              keyboardType="phone-pad"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              value={formData.email}
              onChangeText={(value) => updateField('email', value)}
              placeholder="Enter email address"
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#22577A',
  },
  cancelButton: {
    color: '#666',
    fontSize: 16,
  },
  saveButton: {
    color: '#22577A',
    fontSize: 16,
    fontWeight: 'bold',
  },
  disabledButton: {
    opacity: 0.5,
  },
  form: {
    flex: 1,
    padding: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#22577A',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
});

export default EditDoctorModal;
