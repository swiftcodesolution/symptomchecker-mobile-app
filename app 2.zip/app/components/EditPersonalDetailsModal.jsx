import React, { useState, useEffect } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert
} from 'react-native';
import { savePersonalDetails } from '../services/firebaseService';

const EditPersonalDetailsModal = ({ visible, onClose, currentDetails, onSave }) => {
  const [formData, setFormData] = useState({
    name: currentDetails?.name || '',
    contactNo: currentDetails?.contactNo || '',
    address: currentDetails?.address || '',
    email: currentDetails?.email || '',
    dateOfBirth: currentDetails?.dateOfBirth || '',
    emergencyContact: currentDetails?.emergencyContact || '',
    bloodGroup: currentDetails?.bloodGroup || '',
    medicalConditions: currentDetails?.medicalConditions || '',
    allergies: currentDetails?.allergies || '',
    medications: currentDetails?.medications || '',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (currentDetails) {
      setFormData(currentDetails);
    }
  }, [currentDetails]);

  const handleSave = async () => {
    try {
      setLoading(true);
      const filteredData = {};
      Object.keys(formData).forEach(key => {
        const value = formData[key];
        if (value !== undefined && value !== null && typeof value === 'string') {
          const trimmedValue = value.trim();
          if (trimmedValue !== '') {
            filteredData[key] = trimmedValue;
          }
        } else if (value !== undefined && value !== null) {
          filteredData[key] = value;
        }
      });
  
      await savePersonalDetails(filteredData);
      onSave(filteredData);
      onClose();
    } catch (error) {
      console.error('Error saving personal details:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose}>
            <Text style={styles.cancelButton}>Cancel</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Edit Personal Details</Text>
          <TouchableOpacity onPress={handleSave} disabled={loading}>
            <Text style={[styles.saveButton, loading && styles.disabledButton]}>
              {loading ? 'Saving...' : 'Save'}
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Name</Text>
            <TextInput
              style={styles.input}
              value={formData.name}
              onChangeText={(value) => updateField('name', value)}
              placeholder="Enter your name"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Contact Number</Text>
            <TextInput
              style={styles.input}
              value={formData.contactNo}
              onChangeText={(value) => updateField('contactNo', value)}
              placeholder="Enter contact number"
              keyboardType="phone-pad"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Address</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={formData.address}
              onChangeText={(value) => updateField('address', value)}
              placeholder="Enter your address"
              multiline
              numberOfLines={3}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Blood Group</Text>
            <TextInput
              style={styles.input}
              value={formData.bloodGroup}
              onChangeText={(value) => updateField('bloodGroup', value)}
              placeholder="e.g., O+, A-, B+"
            />
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#22577A',
  },
  cancelButton: {
    color: '#666',
    fontSize: 16,
  },
  saveButton: {
    color: '#22577A',
    fontSize: 16,
    fontWeight: 'bold',
  },
  disabledButton: {
    opacity: 0.5,
  },
  form: {
    flex: 1,
    padding: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#22577A',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
});

export default EditPersonalDetailsModal;
