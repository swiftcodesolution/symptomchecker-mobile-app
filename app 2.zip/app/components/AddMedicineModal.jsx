import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  TextInput,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { firestore } from '../config/firebase';
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const AddMedicineModal = ({ visible, onClose, onMedicineAdded, editingMedicine = null, showSuccessAlert, showErrorAlert }) => {
  const [formData, setFormData] = useState({
    name: editingMedicine?.name || '',
    dosage: editingMedicine?.dosage || '',
    frequency: editingMedicine?.frequency || '',
    timeToTake: editingMedicine?.timeToTake || '',
    refillDate: editingMedicine?.refillDate || ''
  });
  const [loading, setLoading] = useState(false);

  const auth = getAuth();
  const user = auth.currentUser;

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const validateForm = () => {
    if (!formData.name.trim()) {
      Alert.alert('Error', 'Please enter medicine name');
      return false;
    }
    if (!formData.dosage.trim()) {
      Alert.alert('Error', 'Please enter dosage');
      return false;
    }
    if (!formData.frequency.trim()) {
      Alert.alert('Error', 'Please enter frequency');
      return false;
    }
    if (!formData.timeToTake.trim()) {
      Alert.alert('Error', 'Please enter time to take');
      return false;
    }
    if (!formData.refillDate.trim()) {
      Alert.alert('Error', 'Please enter refill date');
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    if (!user) {
      Alert.alert('Error', 'Please login to add medicines');
      return;
    }

    setLoading(true);
    try {
      const medicineData = {
        ...formData,
        userId: user.uid,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      if (editingMedicine) {
        // Update existing medicine
        const medicineRef = doc(firestore, 'medicines', editingMedicine.id);
        await updateDoc(medicineRef, {
          ...formData,
          updatedAt: new Date().toISOString()
        });
        if (showSuccessAlert) {
          showSuccessAlert('Medicine updated successfully!');
        } else {
          Alert.alert('Success', 'Medicine updated successfully!');
        }
      } else {
        // Add new medicine
        const docRef = await addDoc(collection(firestore, 'medicines'), medicineData);
        if (showSuccessAlert) {
          showSuccessAlert('Medicine added successfully!');
        } else {
          Alert.alert('Success', 'Medicine added successfully!');
        }
      }

      onMedicineAdded();
      handleClose();
    } catch (error) {
      console.error('Error saving medicine:', error);
      if (showErrorAlert) {
        showErrorAlert('Failed to save medicine. Please try again.');
      } else {
        Alert.alert('Error', 'Failed to save medicine. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setFormData({
      name: '',
      dosage: '',
      frequency: '',
      timeToTake: '',
      refillDate: ''
    });
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={handleClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Header */}
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {editingMedicine ? 'Edit Medicine' : 'Add Medicine'}
              </Text>
              <TouchableOpacity onPress={handleClose} style={styles.closeButton}>
                <Icon name="x" size={24} color="#6B705B" />
              </TouchableOpacity>
            </View>

            {/* Form Fields */}
            <View style={styles.formContainer}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Medicine Name *</Text>
                <TextInput
                  style={styles.textInput}
                  value={formData.name}
                  onChangeText={(text) => handleInputChange('name', text)}
                  placeholder="Enter medicine name"
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Dosage *</Text>
                <TextInput
                  style={styles.textInput}
                  value={formData.dosage}
                  onChangeText={(text) => handleInputChange('dosage', text)}
                  placeholder="e.g., 500mg, 1 tablet"
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Frequency *</Text>
                <TextInput
                  style={styles.textInput}
                  value={formData.frequency}
                  onChangeText={(text) => handleInputChange('frequency', text)}
                  placeholder="e.g., 2 times per day"
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Time to Take *</Text>
                <TextInput
                  style={styles.textInput}
                  value={formData.timeToTake}
                  onChangeText={(text) => handleInputChange('timeToTake', text)}
                  placeholder="e.g., 9:00 AM, 2:00 PM"
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Refill Date *</Text>
                <TextInput
                  style={styles.textInput}
                  value={formData.refillDate}
                  onChangeText={(text) => handleInputChange('refillDate', text)}
                  placeholder="DD/MM/YYYY"
                  placeholderTextColor="#999"
                />
              </View>
            </View>

            {/* Action Buttons */}
            <View style={styles.buttonContainer}>
              <TouchableOpacity 
                style={[styles.submitButton, loading && styles.disabledButton]} 
                onPress={handleSubmit}
                disabled={loading}
              >
                <Icon name="check" size={18} color="#fff" />
                <Text style={styles.submitButtonText}>
                  {loading ? 'Saving...' : (editingMedicine ? 'Update' : 'Submit')}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.cancelButton} onPress={handleClose}>
                <Icon name="x" size={18} color="#6B705B" />
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

export default AddMedicineModal;

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    width: '90%',
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#6B705B',
  },
  closeButton: {
    padding: 5,
  },
  formContainer: {
    marginBottom: 30,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#24507A',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E9E9E0',
    borderRadius: 12,
    padding: 15,
    fontSize: 16,
    color: '#495057',
    backgroundColor: '#F8F9FA',
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 15,
  },
  submitButton: {
    flex: 1,
    backgroundColor: '#6B705B',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  disabledButton: {
    backgroundColor: '#ccc',
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: '#E9E9E0',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6B705B',
  },
}); 