import React, { useState, useEffect } from 'react';
import {
    Modal,
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    ScrollView,
    Alert
} from 'react-native';
import { saveInsuranceDetails } from '../services/firebaseService';

const EditInsuranceModal = ({ visible, onClose, currentInsurance, onSave }) => {
    const [formData, setFormData] = useState({
        companyName: '',
        policyNo: '',
        contactPersonName: '',
        contactPersonNo: '',
        issueDate: '',
        expiryDate: '',
        coverageAmount: '',
        policyType: '',
        notes: ''
    });
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (currentInsurance) {
            setFormData(currentInsurance);
        } else {
            // Reset form for new insurance
            setFormData({
                companyName: '',
                policyNo: '',
                contactPersonName: '',
                contactPersonNo: '',
                issueDate: '',
                expiryDate: '',
                coverageAmount: '',
                policyType: '',
                notes: ''
            });
        }
    }, [currentInsurance]);

    const handleSave = async () => {
        if (!formData.companyName || !formData.policyNo) {
            Alert.alert('Error', 'Company name and policy number are required.');
            return;
        }
    
        try {
            setLoading(true);
    
            // Filter out empty fields safely
            const filteredData = {};
            Object.keys(formData).forEach(key => {
                const value = formData[key];
                
                // Only process if the value exists
                if (value !== undefined && value !== null) {
                    // If it's a string, trim it and only include if not empty
                    if (typeof value === 'string') {
                        const trimmedValue = value.trim();
                        if (trimmedValue !== '') {
                            filteredData[key] = trimmedValue;
                        }
                    } else {
                        // For non-string values (numbers, dates), include as-is
                        filteredData[key] = value;
                    }
                }
            });
    
            await saveInsuranceDetails(filteredData);
            onSave();
            onClose();
        } catch (error) {
            console.error('Error saving insurance details:', error);
        } finally {
            setLoading(false);
        }
    };

    const updateField = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    return (
        <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
            <View style={styles.container}>
                <View style={styles.header}>
                    <TouchableOpacity onPress={onClose}>
                        <Text style={styles.cancelButton}>Cancel</Text>
                    </TouchableOpacity>
                    <Text style={styles.title}>
                        {currentInsurance ? 'Edit Insurance' : 'Add Insurance'}
                    </Text>
                    <TouchableOpacity onPress={handleSave} disabled={loading}>
                        <Text style={[styles.saveButton, loading && styles.disabledButton]}>
                            {loading ? 'Saving...' : 'Save'}
                        </Text>
                    </TouchableOpacity>
                </View>

                <ScrollView style={styles.form}>
                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Company Name *</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.companyName}
                            onChangeText={(value) => updateField('companyName', value)}
                            placeholder="Enter insurance company name"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Policy Number *</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.policyNo}
                            onChangeText={(value) => updateField('policyNo', value)}
                            placeholder="Enter policy number"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Contact Person Name</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.contactPersonName}
                            onChangeText={(value) => updateField('contactPersonName', value)}
                            placeholder="Enter contact person name"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Contact Person Number</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.contactPersonNo}
                            onChangeText={(value) => updateField('contactPersonNo', value)}
                            placeholder="Enter contact number"
                            keyboardType="phone-pad"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Issue Date</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.issueDate}
                            onChangeText={(value) => updateField('issueDate', value)}
                            placeholder="DD/MM/YYYY"
                        />
                    </View>

                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Expiry Date</Text>
                        <TextInput
                            style={styles.input}
                            value={formData.expiryDate}
                            onChangeText={(value) => updateField('expiryDate', value)}
                            placeholder="DD/MM/YYYY"
                        />
                    </View>
                </ScrollView>
            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#e0e0e0',
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#22577A',
    },
    cancelButton: {
        color: '#666',
        fontSize: 16,
    },
    saveButton: {
        color: '#22577A',
        fontSize: 16,
        fontWeight: 'bold',
    },
    disabledButton: {
        opacity: 0.5,
    },
    form: {
        flex: 1,
        padding: 16,
    },
    inputGroup: {
        marginBottom: 16,
    },
    label: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#22577A',
        marginBottom: 8,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 8,
        padding: 12,
        fontSize: 16,
        backgroundColor: '#f9f9f9',
    },
    textArea: {
        height: 80,
        textAlignVertical: 'top',
    },
});

export default EditInsuranceModal;
