import { View, Text, StyleSheet, Image, TouchableOpacity, TextInput, ScrollView, Animated, Easing, ActivityIndicator, Alert } from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AnimatedBackground from '../components/AnimatedBackground';
import Header from '../components/Header';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState, useRef, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { selectAnswers, setAnswer } from '../redux/slices/userInfoSlice';
import { firestore, firebaseAuth } from '../config/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useRouter, useLocalSearchParams } from "expo-router";
import { toast } from "sonner-native";

const profileImg = require('../../assets/user.jpg');

const question = [
  { id: 1, text: 'What is your Name?' },
  { id: 2, text: 'what your Date of Birth?' },
  { id: 3, text: 'Have you had any surgeries in the past?' },
];

const HEADER_HEIGHT = 380;

const MedicalHistory = () => {
  const { theme } = useTheme();
  const router = useRouter();
  const navigation = useNavigation();
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const [loading, setLoading] = useState(true);
  const [questions, setQuestions] = useState([]);
  const [saving, setSaving] = useState(false);
  const lastScrollY = useRef(0);
  const anim = useRef(new Animated.Value(0)).current;
  const dispatch = useDispatch();
  const params = useLocalSearchParams()

  // Get local answers from Redux
  const localAnswers = useSelector(selectAnswers);

  // Fetch medical history from Firebase
  useEffect(() => {
    const fetchMedicalHistory = async () => {
      try {
        const user = firebaseAuth.currentUser;
        if (!user) {
          console.log("No user logged in");
          return;
        }

        const userDocRef = doc(firestore, "users", user.uid);
        const docSnap = await getDoc(userDocRef);

        // Start with the hardcoded questions as base
        const baseQuestions = [...question];

        if (docSnap.exists()) {
          const userData = docSnap.data();
          console.log("Fetched user data:", userData);

          if (userData.answers && userData.answers.length > 0) {
            // Merge answers with the base questions
            const mergedQuestions = baseQuestions.map((q, index) => {
              const answer = userData.answers[index] || {};
              return {
                ...q,
                text: q.text,
                fullAnswer: answer.answer || "No answer provided",
                summarizedAnswer: answer.summarizedAnswer || "No summary available"
              };
            });
            setQuestions(mergedQuestions);
          } else {
            const localQuestions = baseQuestions.map((q, index) => {
              const answer = localAnswers[index] || {};
              return {
                ...q,
                fullAnswer: answer.answer || "No answer provided",
                summarizedAnswer: answer.summarizedAnswer || "No summary available"
              };
            });
            setQuestions(localQuestions);
          }
        } else {
          const localQuestions = baseQuestions.map((q, index) => {
            const answer = localAnswers[index] || {};
            return {
              ...q,
              fullAnswer: answer.answer || "No answer provided",
              summarizedAnswer: answer.summarizedAnswer || "No summary available"
            };
          });
          setQuestions(localQuestions);
        }
      } catch (error) {
        console.error("Error fetching medical history:", error);
        const localQuestions = question.map((q, index) => {
          const answer = localAnswers[index] || {};
          return {
            ...q,
            fullAnswer: answer.answer || "No answer provided",
            summarizedAnswer: answer.summarizedAnswer || "No summary available"
          };
        });
        setQuestions(localQuestions);
      } finally {
        setLoading(false);
      }
    };

    fetchMedicalHistory();
  }, []);

  console.warn("router.params?.fromEdit===>>>>>>> ", params);


  useEffect(() => {
    const handleAutoSave = async () => {
      if (params?.fromEdit) {
        try {
          setSaving(true);
          const user = firebaseAuth.currentUser;
          if (!user) return;

          // First get the current data from Firebase
          const userDocRef = doc(firestore, "users", user.uid);
          const docSnap = await getDoc(userDocRef);
          const existingData = docSnap.exists() ? docSnap.data() : { answers: [] };

          // Merge existing answers with our local changes
          const mergedAnswers = Array(question.length).fill(null).map((_, index) => {
            // Prefer the local answer if it exists and isn't empty
            const localAnswer = localAnswers[index];
            if (localAnswer?.answer && localAnswer.answer.trim() !== "") {
              return {
                answer: localAnswer.answer,
                summarizedAnswer: localAnswer.summarizedAnswer || ""
              };
            }

            // Otherwise use the existing answer from Firebase if available
            const existingAnswer = existingData.answers?.[index] || {};
            return {
              answer: existingAnswer.answer || "",
              summarizedAnswer: existingAnswer.summarizedAnswer || ""
            };
          });

          console.log("Merged answers:", mergedAnswers);

          // Prepare data for Firestore
          const userData = {
            answers: mergedAnswers,
            updatedAt: new Date().toISOString(),
          };

          // Save to Firestore
          await setDoc(userDocRef, userData, { merge: true });

          // Update local state
          const updatedQuestions = question.map((q, index) => {
            const answer = mergedAnswers[index] || {};
            return {
              ...q,
              fullAnswer: answer.answer || "No answer provided",
              summarizedAnswer: answer.summarizedAnswer || "No summary available"
            };
          });
          setQuestions(updatedQuestions);

          toast("Changes saved successfully!");
        } catch (error) {
          console.error("Auto-save failed:", error);
          Alert.alert("Error", "Failed to auto-save changes");
        } finally {
          setSaving(false);
        }
      }
    };

    handleAutoSave();
  }, [params?.fromEdit]);

  const animateHeader = (show) => {
    Animated.timing(anim, {
      toValue: show ? 0 : -HEADER_HEIGHT,
      duration: 350,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  };

  const handleScroll = (event) => {
    const currentY = event.nativeEvent.contentOffset.y;
    const delta = currentY - lastScrollY.current;
    if (Math.abs(delta) < 10) return;
    if (delta > 0 && isHeaderVisible && currentY > 40) {
      setIsHeaderVisible(false);
      animateHeader(false);
    } else if (delta < 0 && !isHeaderVisible && currentY < 60) {
      setIsHeaderVisible(true);
      animateHeader(true);
    }
    lastScrollY.current = currentY;
  };

  const handleEdit = (questionId) => {
    router.push({
      pathname: '/collect-user-info',
      params: {
        editMedical: 'true',
        questionIndex: questionId - 1,
        fromMedicalHistory: 'true'
      }
    });
  };

  if (loading || saving) {
    return (
      <AnimatedBackground>
        <SafeAreaView style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color={theme.primary} />
        </SafeAreaView>
      </AnimatedBackground>
    );
  }

  return (
    <AnimatedBackground>
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.contentSection}>
          <Animated.View
            style={[
              styles.animatedContent,
              {
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                marginLeft: "5%",
                transform: [{ translateY: anim }],
                opacity: anim.interpolate({
                  inputRange: [-HEADER_HEIGHT, 0],
                  outputRange: [0, 1],
                }),
              },
            ]}
          >
            <Header
              profileImage={profileImg}
              greeting="Hello Scott"
              location="SC, 702 USA"
              sos={true}
            />
            <Text style={styles.title}>Medical History</Text>
            <View style={styles.searchBarWrapper}>
              <TextInput
                style={styles.searchBar}
                placeholder="Search your medical history"
                placeholderTextColor="#7c7c7c"
              />
            </View>
          </Animated.View>
          <View style={styles.listWrapper}>
            <ScrollView
              contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_HEIGHT }]}
              showsVerticalScrollIndicator={false}
              onScroll={handleScroll}
              scrollEventThrottle={16}
              style={styles.scrollView}
            >
              {questions.map((q) => {
                const hasAnswer = q.fullAnswer && q.fullAnswer !== "No answer provided";

                return (
                  <View key={q.id} style={styles.card}>
                    <Ionicons
                      name={hasAnswer ? "checkmark-done-circle-outline" : "alert-circle-outline"}
                      size={28}
                      color={hasAnswer ? "#00FF57" : "#FFA500"}
                      style={styles.checkIcon}
                    />
                    <View style={styles.textContainer}>
                      <Text style={styles.questionText}>{q.text}</Text>
                      {hasAnswer ? (
                        <Text style={styles.answerText}>
                          {q.fullAnswer.length > 30
                            ? q.fullAnswer.slice(0, 30) + '...'
                            : q.fullAnswer}
                        </Text>
                      ) : (
                        <Text style={styles.noAnswerText}>No answer provided</Text>
                      )}
                    </View>
                    <TouchableOpacity
                      style={styles.editBtn}
                      onPress={() => handleEdit(q.id)}
                    >
                      <Text style={styles.editText}>
                        {hasAnswer ? 'Edit' : 'Add'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                );
              })}
            </ScrollView>
          </View>
        </View>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  title: {
    fontSize: 36,
    color: '#4d5a5a',
    textAlign: 'center',
    fontWeight: '400',
    marginBottom: 18,
  },
  contentSection: {
    paddingHorizontal: 18,
    flex: 1,
  },
  animatedContent: {
    zIndex: 1,
    backgroundColor: 'transparent',
    width: '100%',
  },
  searchBarWrapper: {
    width: '90%',
    marginBottom: 18,
    backgroundColor: '#e5e8de',
    borderRadius: 28,
    paddingHorizontal: 18,
    paddingVertical: 6,
    marginLeft: "5%"
  },
  searchBar: {
    fontSize: 20,
    color: '#4d5a5a',
    paddingVertical: 8,
    backgroundColor: 'transparent',
  },
  listWrapper: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#d3cdc3',
    borderRadius: 32,
    paddingVertical: 22,
    paddingHorizontal: 18,
    width: '100%',
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
  },
  checkIcon: { marginRight: 12 },
  cardText: {
    flex: 1,
    fontSize: 20,
    color: '#222',
    fontWeight: '500',
  },
  editBtn: {
    paddingHorizontal: 10,
    paddingVertical: 2,
  },
  editText: {
    color: '#222',
    fontSize: 18,
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 18,
    color: '#4d5a5a',
    marginBottom: 20,
  },
  addButton: {
    backgroundColor: '#6B705B',
    padding: 15,
    borderRadius: 10,
  },
  addButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  textContainer: {
    flex: 1,
    marginLeft: 10,
  },
  questionText: {
    fontSize: 16,
    color: '#222',
    fontWeight: '600',
  },
  answerText: {
    fontSize: 14,
    color: '#4d5a5a',
    marginTop: 4,
  },
  noAnswerText: {
    fontSize: 14,
    color: '#FFA500',
    marginTop: 4,
    fontStyle: 'italic',
  },
  saveButton: {
    borderRadius: 24,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
    marginBottom: 40,
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});

export default MedicalHistory;