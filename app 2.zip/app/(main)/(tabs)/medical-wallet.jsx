import { ScrollView, StyleSheet, Text, View, Image, TouchableOpacity, Animated, Easing } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import SmallButton from "../../components/SmallButton";
import { useTheme } from "../../theme/ThemeContext";
import { useNavigation } from '@react-navigation/native';
import AnimatedBackground from "../../components/AnimatedBackground";
import Header from "../../components/Header";
import { useState, useRef, useEffect } from "react";
import EditPersonalDetailsModal from "../../components/EditPersonalDetailsModal";
import EditInsuranceModal from "../../components/EditInsuranceModal";
import EditDoctorModal from "../../components/EditDoctorModal";
import EditPharmacyModal from "../../components/EditPharmacyModal";
import EditPersonalContactsModal from "../../components/EditPersonalContactsModal";
import {
  getPersonalDetails,
  getInsuranceDetails,
  getDoctorDetails,
  getPharmacyDetails,
  getPersonalContacts,
  deleteInsuranceDetails,
  deleteDoctorDetails,
  deletePharmacyDetails,
  addPersonalContact,
  updatePersonalContact,
  deletePersonalContact
} from "../../services/firebaseService";
import Icon from "react-native-vector-icons/Feather"

const profileImg = require("../../../assets/user.jpg");
const HEADER_HEIGHT = 300;

const MedicalWallet = () => {
  const { theme } = useTheme();
  const navigation = useNavigation();
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const lastScrollY = useRef(0);
  const anim = useRef(new Animated.Value(0)).current;

  const [alert, setAlert] = useState({
    visible: false,
    title: '',
    message: '',
    type: 'info',
    onConfirm: null,
    onCancel: null
  });

  // Data states
  const [personalDetails, setPersonalDetails] = useState(null);
  const [insuranceList, setInsuranceList] = useState([]);
  const [doctorList, setDoctorList] = useState([]);
  const [pharmacyList, setPharmacyList] = useState([]);
  const [contactsList, setContactsList] = useState([]);
  const [contactsModalVisible, setContactsModalVisible] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [loading, setLoading] = useState(true);

  // Modal states
  const [personalModalVisible, setPersonalModalVisible] = useState(false);
  const [insuranceModalVisible, setInsuranceModalVisible] = useState(false);
  const [doctorModalVisible, setDoctorModalVisible] = useState(false);
  const [pharmacyModalVisible, setPharmacyModalVisible] = useState(false);

  // Edit states
  const [editingInsurance, setEditingInsurance] = useState(null);
  const [editingDoctor, setEditingDoctor] = useState(null);
  const [editingPharmacy, setEditingPharmacy] = useState(null);

  // Helper function to show alerts
  const showAlert = (title, message, type = 'info', onConfirm = null, onCancel = null) => {
    setAlert({
      visible: true,
      title,
      message,
      type,
      onConfirm: onConfirm || (() => hideAlert()),
      onCancel: onCancel || (() => hideAlert())
    });
  };

  const hideAlert = () => {
    setAlert(prev => ({ ...prev, visible: false }));
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    try {
      setLoading(true);
      const [personal, insurance, doctors, pharmacies, contacts] = await Promise.all([
        getPersonalDetails(),
        getInsuranceDetails(),
        getDoctorDetails(),
        getPharmacyDetails(),
        getPersonalContacts()
      ]);

      setPersonalDetails(personal);
      setInsuranceList(insurance);
      setDoctorList(doctors);
      setPharmacyList(pharmacies);
      setContactsList(contacts);
    } catch (error) {
      console.error('Error loading data:', error);
      showAlert('Error', 'Failed to load data. Please try again.', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Add these handler functions
  const handleAddContact = () => {
    setEditingContact(null);
    setContactsModalVisible(true);
  };

  const handleEditContact = (contact) => {
    setEditingContact(contact);
    setContactsModalVisible(true);
  };

  const handleSaveContact = async (contactData) => {
    try {
      if (editingContact) {
        await updatePersonalContact(editingContact.id, contactData);
      } else {
        await addPersonalContact(contactData);
      }
      loadAllData();
      showAlert('Success', 'Contact saved successfully!', 'success');
    } catch (error) {
      showAlert('Error', 'Failed to save contact.', 'error');
    }
  };

  // Animate header in/out
  const animateHeader = (show) => {
    Animated.timing(anim, {
      toValue: show ? 0 : -HEADER_HEIGHT,
      duration: 350,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  };

  // Scroll handler
  const handleScroll = (event) => {
    const currentY = event.nativeEvent.contentOffset.y;
    const delta = currentY - lastScrollY.current;

    if (Math.abs(delta) < 10) return;

    if (delta > 0 && isHeaderVisible && currentY > 40) {
      setIsHeaderVisible(false);
      animateHeader(false);
    } else if (delta < 0 && !isHeaderVisible && currentY < 60) {
      setIsHeaderVisible(true);
      animateHeader(true);
    }

    lastScrollY.current = currentY;
  };

  const handleEditPersonal = () => {
    setPersonalModalVisible(true);
  };

  const handleAddInsurance = () => {
    setEditingInsurance(null);
    setInsuranceModalVisible(true);
  };

  const handleEditInsurance = (insurance) => {
    setEditingInsurance(insurance);
    setInsuranceModalVisible(true);
  };

  const handleDeleteInsurance = (id) => {
    showAlert(
      'Delete Insurance',
      'Are you sure you want to delete this insurance?',
      'warning',
      () => { // This is a placeholder for a confirm action, actual implementation would be in AlertModal
        // For now, directly call delete
        deleteInsuranceDetails(id)
          .then(() => {
            loadAllData();
            showAlert('Success', 'Insurance deleted successfully!', 'success');
          })
          .catch((error) => {
            showAlert('Error', 'Failed to delete insurance.', 'error');
          });
        hideAlert(); // Hide the alert after action
      }
    );
    // Since the custom AlertModal doesn't have a direct confirm/cancel,
    // we'll simulate it by directly calling the delete function on 'OK'
    // A more advanced AlertModal would have multiple buttons and callbacks.
    // For now, the 'warning' type indicates a destructive action.
    deleteInsuranceDetails(id)
      .then(() => {
        loadAllData();
        showAlert('Success', 'Insurance deleted successfully!', 'success');
      })
      .catch((error) => {
        showAlert('Error', 'Failed to delete insurance.', 'error');
      });
  };

  const handleAddDoctor = () => {
    setEditingDoctor(null);
    setDoctorModalVisible(true);
  };

  const handleEditDoctor = (doctor) => {
    setEditingDoctor(doctor);
    setDoctorModalVisible(true);
  };

  const handleDeleteDoctor = (id) => {
    showAlert(
      'Delete Doctor',
      'Are you sure you want to delete this doctor?',
      'warning',
      () => {
        deleteDoctorDetails(id)
          .then(() => {
            loadAllData();
            showAlert('Success', 'Doctor deleted successfully!', 'success');
          })
          .catch((error) => {
            showAlert('Error', 'Failed to delete doctor.', 'error');
          });
        hideAlert();
      }
    );
    deleteDoctorDetails(id)
      .then(() => {
        loadAllData();
        showAlert('Success', 'Doctor deleted successfully!', 'success');
      })
      .catch((error) => {
        showAlert('Error', 'Failed to delete doctor.', 'error');
      });
  };

  const handleDeleteContact = (id) => {
    showAlert(
      'Delete Contact',
      'Are you sure you want to delete this contact?',
      'warning',
      () => {
        deletePersonalContact(id)
          .then(() => {
            loadAllData();
            showAlert('Success', 'Contact deleted successfully!', 'success');
          })
          .catch((error) => {
            showAlert('Error', 'Failed to delete contact.', 'error');
          });
        hideAlert();
      }
    );
    deletePersonalContact(id)
    .then(() => {
      loadAllData();
      showAlert('Success', 'Doctor deleted successfully!', 'success');
    })
    .catch((error) => {
      showAlert('Error', 'Failed to delete doctor.', 'error');
    });
  };

  const handleAddPharmacy = () => {
    setEditingPharmacy(null);
    setPharmacyModalVisible(true);
  };

  const handleEditPharmacy = (pharmacy) => {
    setEditingPharmacy(pharmacy);
    setPharmacyModalVisible(true);
  };

  const handleDeletePharmacy = (id) => {
    showAlert(
      'Delete Pharmacy',
      'Are you sure you want to delete this pharmacy?',
      'warning',
      () => {
        deletePharmacyDetails(id)
          .then(() => {
            loadAllData();
            showAlert('Success', 'Pharmacy deleted successfully!', 'success');
          })
          .catch((error) => {
            showAlert('Error', 'Failed to delete pharmacy.', 'error');
          });
        hideAlert();
      }
    );
    deletePharmacyDetails(id)
      .then(() => {
        loadAllData();
        showAlert('Success', 'Pharmacy deleted successfully!', 'success');
      })
      .catch((error) => {
        showAlert('Error', 'Failed to delete pharmacy.', 'error');
      });
  };

  const renderPersonalDetails = () => {
    if (!personalDetails) {
      return (
        <View style={styles.emptyState}>
          <Text style={styles.emptyText}>No personal details added yet</Text>
         
        </View>
      );
    }

    return (
      <View style={styles.detailsContent}>
        {personalDetails.name && (
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Name:</Text>
            <Text style={styles.detailValue}>{personalDetails.name}</Text>
            {personalDetails.bloodGroup && (
              <Text style={styles.bloodGroup}>Blood Group: {personalDetails.bloodGroup}</Text>
            )}
          </View>
        )}
        {personalDetails.contactNo && (
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Contact No:</Text>
            <Text style={styles.detailValue}>{personalDetails.contactNo}</Text>
          </View>
        )}
        {personalDetails.address && (
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Address:</Text>
            <Text style={styles.detailValue}>{personalDetails.address}</Text>
          </View>
        )}
      </View>
    );
  };

  const renderInsuranceList = () => {
    if (insuranceList.length === 0) {
      return (
        <View style={styles.emptyState}>
          <Text style={styles.emptyText}>No insurance details added yet</Text>
          <TouchableOpacity onPress={handleAddInsurance} style={styles.addButton}>
            <Text style={styles.addButtonText}>Add Insurance</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return insuranceList.map((insurance, index) => (
      <View key={insurance.id || index} style={styles.listItem}>
        <View style={styles.listItemContent}>
          <Text style={styles.listItemTitle}>{insurance.companyName}</Text>
          <Text style={styles.listItemSubtitle}>Policy: {insurance.policyNo}</Text>
          {insurance.contactPersonName && (
            <Text style={styles.listItemDetail}>Contact: {insurance.contactPersonName}</Text>
          )}
          {insurance.expiryDate && (
            <Text style={styles.listItemDetail}>Expires: {insurance.expiryDate}</Text>
          )}
        </View>
        <View style={styles.listItemActions}>
          <TouchableOpacity onPress={() => handleEditInsurance(insurance)} style={styles.editButton}>
            <Text style={styles.editButtonText}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleDeleteInsurance(insurance.id)} style={styles.deleteButton}>
            <Text style={styles.deleteButtonText}>Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
    ));
  };

  const renderDoctorList = () => {
    if (doctorList.length === 0) {
      return (
        <View style={styles.emptyState}>
          <Text style={styles.emptyText}>No doctor details added yet</Text>
          <TouchableOpacity onPress={handleAddDoctor} style={styles.addButton}>
            <Text style={styles.addButtonText}>Add Doctor</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return doctorList.map((doctor, index) => (
      <View key={doctor.id || index} style={styles.listItem}>
        <View style={styles.listItemContent}>
          <Text style={styles.listItemTitle}>{doctor.doctorName}</Text>
          {doctor.specialization && (
            <Text style={styles.listItemSubtitle}>{doctor.specialization}</Text>
          )}
          <Text style={styles.listItemDetail}>Phone: {doctor.phoneNo}</Text>
          {doctor.hospitalName && (
            <Text style={styles.listItemDetail}>Hospital: {doctor.hospitalName}</Text>
          )}
        </View>
        <View style={styles.listItemActions}>
          <TouchableOpacity onPress={() => handleEditDoctor(doctor)} style={styles.editButton}>
            <Text style={styles.editButtonText}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleDeleteDoctor(doctor.id)} style={styles.deleteButton}>
            <Text style={styles.deleteButtonText}>Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
    ));
  };

  const renderPharmacyList = () => {
    if (pharmacyList.length === 0) {
      return (
        <View style={styles.emptyState}>
          <Text style={styles.emptyText}>No pharmacy added yet</Text>
          <TouchableOpacity onPress={handleAddPharmacy} style={styles.addButton}>
            <Text style={styles.addButtonText}>Add Pharmacy</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return (
      <View style={styles.pharmacyRow}>
        {pharmacyList.slice(0, 2).map((pharmacy, index) => (
          <TouchableOpacity
            key={pharmacy.id || index}
            style={styles.pharmacyCard}
            onPress={() => handleEditPharmacy(pharmacy)}
          >
            <Image source={require('../../../assets/pharmacy-logo.png')} style={styles.pharmacyLogo} />
            <Text style={styles.pharmacyName}>{pharmacy.pharmacyName}</Text>
            <Text style={styles.pharmacyAddress}>{pharmacy.address}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity style={[styles.pharmacyCard, styles.addPharmacyCard]} onPress={handleAddPharmacy}>
          <Text style={styles.addPharmacyText}>+</Text>
        </TouchableOpacity>
      </View>
    );
  };

  if (loading) {
    return (
      <AnimatedBackground>
        <SafeAreaView style={{ flex: 1 }}>
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading...</Text>
          </View>
        </SafeAreaView>
      </AnimatedBackground>
    );
  }

  return (
    <AnimatedBackground>
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.contentSection}>
          <Animated.View
            style={[
              styles.animatedContent,
              {
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                marginLeft: "5%",
                transform: [{ translateY: anim }],
                opacity: anim.interpolate({
                  inputRange: [-HEADER_HEIGHT, 0],
                  outputRange: [0, 1],
                }),
              },
            ]}
          >
            <Header
              profileImage={profileImg}
              greeting="Hello Scott"
              location="SC, 702 USA"
              sos={true}
            />
            <Text style={styles.pageTitle}>Medical Wallet</Text>
          </Animated.View>

          <View style={styles.listWrapper}>
            <ScrollView
              style={[styles.scrollViewStyles]}
              contentContainerStyle={styles.scrollViewStylesInner}
              showsVerticalScrollIndicator={false}
              onScroll={handleScroll}
              scrollEventThrottle={16}
            >
              <View style={styles.contentPadding}>
                {/* Personal Details Card */}
                <View style={[styles.card, { marginTop: HEADER_HEIGHT }]}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Personal Details</Text>
                    <SmallButton btnText="Edit" pressFunction={handleEditPersonal} />
                  </View>
                  {renderPersonalDetails()}
                </View>

                {/* Insurance Details Card */}
                <View style={styles.card}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Insurance Details</Text>
                    <SmallButton btnText="Add" pressFunction={handleAddInsurance} />
                  </View>
                  {renderInsuranceList()}
                </View>

                {/* Doctor Details Card */}
                <View style={styles.card}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Doctor Details</Text>
                    <SmallButton btnText="Add" pressFunction={handleAddDoctor} />
                  </View>
                  {renderDoctorList()}
                </View>

                {/* Personal Contacts Table */}
                <View style={styles.card}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Personal Contacts</Text>
                    <SmallButton btnText="Add" pressFunction={handleAddContact} />
                  </View>

                  {contactsList.length > 0 ? (
                    <>
                      <View style={styles.tableHeaderRow}>
                        <Text style={styles.tableHeader}>Name</Text>
                        <Text style={styles.tableHeader}>Relation</Text>
                        <Text style={styles.tableHeader}>Contact</Text>
                        <Text style={styles.tableHeader}>Action</Text>
                      </View>
                      {contactsList.map((contact, index) => (
                        <View key={contact.id || index} style={styles.tableRow}>
                          <Text style={[styles.tableCell]}>{contact.Name}</Text>
                          <Text style={styles.tableCell}>{contact.Relation}</Text>
                          <Text style={styles.tableCell}>{contact.ContactNumber}</Text>
                          <View style={[styles.tableCell, { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: -4 }]}>
                            <TouchableOpacity
                              onPress={() => handleEditContact(contact)}
                              style={styles.iconButton}
                            >
                              <Icon name="edit" size={18} color="#22577A" />
                            </TouchableOpacity>
                            <TouchableOpacity
                              onPress={() => handleDeleteContact(contact.id)}
                              style={[styles.iconButton]}
                            >
                              <Icon name="trash-2" size={18} color="#dc3545" />
                            </TouchableOpacity>
                          </View>
                        </View>
                      ))}
                    </>
                  ) : (
                    <View style={styles.emptyState}>
                      <Text style={styles.emptyText}>No contacts added ye</Text>
                    </View>
                  )}
                </View>

                {/* Preferred Pharmacy */}
                <View style={styles.card}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Preferred Pharmacy</Text>
                    {/* <SmallButton btnText="See All" pressFunction={() => showAlert('Info', 'See all pharmacies functionality coming soon!', 'info')} /> */}
                  </View>
                  {renderPharmacyList()}
                </View>
              </View>
            </ScrollView>
          </View>
        </View>

        {/* Modals */}
        <EditPersonalDetailsModal
          visible={personalModalVisible}
          onClose={() => setPersonalModalVisible(false)}
          currentDetails={personalDetails}
          onSave={(details) => {
            setPersonalDetails(details);
            loadAllData();
          }}
          showAlert={showAlert}
          hideAlert={hideAlert}
        />

        <EditInsuranceModal
          visible={insuranceModalVisible}
          onClose={() => setInsuranceModalVisible(false)}
          currentInsurance={editingInsurance}
          onSave={() => {
            loadAllData();
          }}
          showAlert={showAlert}
          hideAlert={hideAlert}
        />

        <EditDoctorModal
          visible={doctorModalVisible}
          onClose={() => setDoctorModalVisible(false)}
          currentDoctor={editingDoctor}
          onSave={() => {
            loadAllData();
          }}
          showAlert={showAlert}
          hideAlert={hideAlert}
        />

        <EditPersonalContactsModal
          visible={contactsModalVisible}
          onClose={() => setContactsModalVisible(false)}
          currentContact={editingContact}
          onSave={() => {
            loadAllData();
          }}
          showAlert={showAlert}
          hideAlert={hideAlert}
        />

        <EditPharmacyModal
          visible={pharmacyModalVisible}
          onClose={() => setPharmacyModalVisible(false)}
          currentPharmacy={editingPharmacy}
          onSave={() => {
            loadAllData();
          }}
          showAlert={showAlert}
          hideAlert={hideAlert}
        />
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default MedicalWallet;

const styles = StyleSheet.create({
  pageTitle: {
    textAlign: 'center',
    fontSize: 22,
    color: '#465D69',
    fontWeight: '500',
    marginBottom: 10,
    marginTop: 10,
  },
  card: {
    backgroundColor: '#E9E7E1',
    borderRadius: 18,
    padding: 16,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  titleBox: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionHeading: {
    color: '#22577A',
    fontSize: 20,
    fontWeight: 'bold',
  },
  detailsContent: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    flexWrap: 'wrap',
  },
  detailLabel: {
    fontWeight: 'bold',
    color: '#22577A',
    marginRight: 6,
  },
  detailValue: {
    color: '#444',
    marginRight: 10,
  },
  bloodGroup: {
    backgroundColor: '#D7F9F1',
    color: '#22577A',
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 2,
    fontSize: 12,
    marginLeft: 8,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  emptyText: {
    color: '#666',
    fontSize: 16,
    marginBottom: 10,
  },
  addButton: {
    backgroundColor: '#22577A',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  listItem: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  listItemContent: {
    flex: 1,
  },
  listItemTitle: {
    fontWeight: 'bold',
    color: '#22577A',
    fontSize: 16,
  },
  listItemSubtitle: {
    color: '#666',
    fontSize: 14,
    marginTop: 2,
  },
  listItemDetail: {
    color: '#444',
    fontSize: 12,
    marginTop: 1,
  },
  listItemActions: {
    flexDirection: 'row',
    gap: 8,
  },
  editButton: {
    backgroundColor: '#22577A',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  editButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: '#dc3545',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  deleteButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  tableHeaderRow: {
    flexDirection: 'row',
    backgroundColor: '#D7F9F1',
    borderRadius: 8,
    paddingVertical: 6,
    marginBottom: 4,
  },
  tableHeader: {
    flex: 1,
    fontWeight: 'bold',
    color: '#22577A',
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 4,
  },
  tableCell: {
    flex: 1,
    color: '#444',
    textAlign: 'center',
  },
  pharmacyRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
    flexWrap: 'wrap'
  },
  pharmacyCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 10,
    alignItems: 'center',
    width: 120,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 1,
  },
  addPharmacyCard: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#22577A',
    backgroundColor: '#E9E7E1',
  },
  addPharmacyText: {
    fontSize: 36,
    color: '#22577A',
    fontWeight: 'bold',
  },
  pharmacyLogo: {
    width: 40,
    height: 40,
    borderRadius: 8,
    marginBottom: 6,
  },
  pharmacyName: {
    fontWeight: 'bold',
    color: '#22577A',
    fontSize: 15,
    marginBottom: 2,
  },
  pharmacyAddress: {
    color: '#444',
    fontSize: 12,
    textAlign: 'center',
  },
  scrollViewStyles: {
    flex: 1,
  },
  scrollViewStylesInner: {
    gap: 20,
    paddingBottom: 20
  },
  contentPadding: {
    paddingHorizontal: 18,
  },
  contentSection: {
    paddingHorizontal: 18,
    flex: 1,
  },
  animatedContent: {
    zIndex: 1,
    backgroundColor: 'transparent',
    width: '100%',
  },
  listWrapper: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 18,
    color: '#22577A',
    fontWeight: 'bold',
  },
  iconButton: {
    padding: 6,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.05)',
  },
});
