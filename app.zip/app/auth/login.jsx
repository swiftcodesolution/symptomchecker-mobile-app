import { StyleSheet, Text, View, TextInput, TouchableOpacity, Image, ScrollView, Alert, Platform, ActivityIndicator, Modal } from "react-native";
import { useTheme } from "../theme/ThemeContext";
import { useRouter } from "expo-router";
import { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import PrimaryButton from "../components/PrimaryButton";
import AnimatedBackground from "../components/AnimatedBackground";
import { MaterialIcons, AntDesign, FontAwesome } from '@expo/vector-icons';
import TitleText from "../components/TitleText";
import * as LocalAuthentication from 'expo-local-authentication';
import { firebaseAuth, firestore } from '../config/firebase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { doc, getDoc } from 'firebase/firestore';

const Login = () => {
  const { theme } = useTheme();
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showBiometricPrompt, setShowBiometricPrompt] = useState(false);

  const handleLogin = async () => {
    setError("");
    if (!email || !password) {
      setError("Please enter both email and password.");
      return;
    }
    setLoading(true);
    try {
      if (!firebaseAuth) {
        throw new Error('Firebase is not properly initialized. Please check your configuration.');
      }
      const { signInWithEmailAndPassword } = await import('firebase/auth');
      const userCredential = await signInWithEmailAndPassword(firebaseAuth, email, password);
      await AsyncStorage.setItem('isLoggedIn', 'true');
      await AsyncStorage.setItem('userEmail', email);
      await checkPersonalInfoAndNavigate();
      // Prompt for biometric setup
      setShowBiometricPrompt(true);
    } catch (error) {
      let errorMessage = "An error occurred during login.";
      switch (error.code) {
        case 'auth/user-not-found':
          errorMessage = "No user found with this email.";
          break;
        case 'auth/wrong-password':
          errorMessage = "Incorrect password.";
          break;
        case 'auth/invalid-email':
          errorMessage = "Please enter a valid email address.";
          break;
        case 'auth/network-request-failed':
          errorMessage = "Network error. Please check your internet connection.";
          break;
        default:
          errorMessage = error.message || errorMessage;
      }
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleEnableBiometric = async () => {
    await AsyncStorage.setItem('biometricEnabled', 'true');
    await AsyncStorage.setItem('biometricEmail', email);
    await AsyncStorage.setItem('biometricPassword', password);
    setShowBiometricPrompt(false);
    await checkPersonalInfoAndNavigate();
  };

  const handleSkipBiometric = async () => {
    setShowBiometricPrompt(false);
    await checkPersonalInfoAndNavigate();
  };

  const checkPersonalInfoAndNavigate = async () => {
    try {
      // Check both AsyncStorage and Firestore
      const user = firebaseAuth.currentUser;

      if (user) {
        // Additional check with Firestore
        const userDocRef = doc(firestore, 'users', user.uid);
        const docSnap = await getDoc(userDocRef);

        if (docSnap.exists() && docSnap.data().answers) {
          router.push("/(main)");
          return;
        }
      }
      router.push("/collect-user-info");
    } catch (error) {
      console.error('Error checking personal info:', error);
      router.push("/collect-user-info");
    }
  };

  // Biometric authentication handler
  const handleBiometricAuth = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const isEnrolled = await LocalAuthentication.isEnrolledAsync();
      if (!hasHardware || !isEnrolled) {
        Alert.alert('Biometric authentication not available', 'Your device does not support biometric authentication or it is not set up.');
        return;
      }
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Authenticate with Biometrics',
        fallbackLabel: 'Enter Passcode',
      });
      if (result.success) {
        // Get stored credentials and login automatically
        const storedEmail = await AsyncStorage.getItem('biometricEmail');
        const storedPassword = await AsyncStorage.getItem('biometricPassword');

        if (storedEmail && storedPassword) {
          setLoading(true);
          try {
            if (!firebaseAuth) {
              throw new Error('Firebase is not properly initialized. Please check your configuration.');
            }
            const { signInWithEmailAndPassword } = await import('firebase/auth');
            await signInWithEmailAndPassword(firebaseAuth, storedEmail, storedPassword);
            await AsyncStorage.setItem('isLoggedIn', 'true');
            await AsyncStorage.setItem('userEmail', storedEmail);
            await checkPersonalInfoAndNavigate();
          } catch (error) {
            let errorMessage = "Biometric login failed. Please try manual login.";
            Alert.alert('Login Failed', errorMessage);
          } finally {
            setLoading(false);
          }
        } else {
          Alert.alert('No stored credentials', 'Please login manually first to enable biometric login.');
        }
      } else {
        Alert.alert('Authentication failed', 'Biometric authentication was not successful.');
      }
    } catch (error) {
      Alert.alert('Error', 'An error occurred during biometric authentication.');
    }
  };

  return (
    <AnimatedBackground>
      <SafeAreaView style={[styles.container]}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View style={styles.logoContainer}>
            <Image source={require('../../assets/logo.png')} style={styles.logo} />
          </View>
          <Text style={styles.welcomeText}>Welcome Back to Your Health Companion</Text>
          <View style={styles.form}>
            <View style={styles.inputWrapper}>
              <MaterialIcons name="email" size={24} color="#fff" style={styles.inputIcon} />
              <TextInput
                style={[styles.input, { color: theme.btnText }]}
                placeholder="Email"
                placeholderTextColor={theme.btnText}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
            <View style={styles.inputWrapper}>
              <MaterialIcons name="lock" size={24} color="#fff" style={styles.inputIcon} />
              <TextInput
                style={[styles.input, { color: theme.btnText }]}
                placeholder="********"
                placeholderTextColor={theme.btnText}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
                <MaterialIcons name={showPassword ? "visibility" : "visibility-off"} size={24} color="#fff" />
              </TouchableOpacity>
            </View>
            {error ? <Text style={{ color: 'red', marginBottom: 8 }}>{error}</Text> : null}
            <TouchableOpacity style={styles.signInBtn} onPress={handleLogin} disabled={loading}>
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.signInBtnText}>Sign in</Text>
              )}
            </TouchableOpacity>
            <TouchableOpacity style={styles.forgotPassword} onPress={() => router.push('/auth/forgot-password')}>
              <Text style={styles.forgotPasswordText}>Forget Password?</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.biometricContainer}>
            <TouchableOpacity style={styles.biometricBtn} onPress={handleBiometricAuth}>
              <Image source={require('../../assets/bio.png')} style={styles.biometricIcon} />
            </TouchableOpacity>
            <Text style={styles.biometricText}>Biometric SignIn</Text>
          </View>
          <View style={styles.socialContainer}>
            <TouchableOpacity style={styles.socialBtn}>
              <AntDesign name="google" size={24} color="#6B705B" style={styles.socialIcon} />
              <Text style={styles.socialBtnText}>Sign Up With Google</Text>
            </TouchableOpacity>
            {Platform.OS === 'ios' && (
              <TouchableOpacity style={styles.socialBtn}>
                <FontAwesome name="apple" size={24} color="#6B705B" style={styles.socialIcon} />
                <Text style={styles.socialBtnText}>Sign Up With Apple</Text>
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.footer}>
            <Text style={styles.footerText}>
              Don't Have Account? <Text style={styles.footerLink} onPress={() => router.push("/auth/signup")}>Sign Up</Text>
            </Text>
          </View>
        </ScrollView>
        {/* Biometric Enable Modal */}
        <Modal
          visible={showBiometricPrompt}
          transparent
          animationType="fade"
        >
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' }}>
            <View style={{ backgroundColor: '#fff', padding: 24, borderRadius: 16, alignItems: 'center', width: 300 }}>
              <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 12, color: '#222' }}>Enable Fingerprint Login?</Text>
              <Text style={{ fontSize: 15, color: '#444', marginBottom: 20, textAlign: 'center' }}>
                Would you like to use your fingerprint to log in faster next time?
              </Text>
              <View style={{ flexDirection: 'row', gap: 16 }}>
                <TouchableOpacity onPress={handleEnableBiometric} style={{ backgroundColor: '#6B705B', paddingVertical: 10, paddingHorizontal: 18, borderRadius: 8 }}>
                  <Text style={{ color: '#fff', fontWeight: '600' }}>Yes</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={handleSkipBiometric} style={{ backgroundColor: '#ccc', paddingVertical: 10, paddingHorizontal: 18, borderRadius: 8 }}>
                  <Text style={{ color: '#222', fontWeight: '600' }}>No</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default Login;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollContent: { flexGrow: 1, justifyContent: 'center', padding: 20 },
  logoContainer: { alignItems: 'center', marginTop: 10, marginBottom: 10 },
  logo: { width: 60, height: 60, resizeMode: 'contain' },
  welcomeText: { textAlign: 'center', color: '#6B705B', fontSize: 16, marginBottom: 18, fontWeight: '500' },
  form: { gap: 12 },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(107, 112, 91, 0.5)",
    borderRadius: 24,
    paddingHorizontal: 18,
    marginBottom: 0,
  },
  inputIcon: { marginRight: 10 },
  input: {
    flex: 1,
    paddingVertical: 20,
    fontSize: 18,
  },
  eyeIcon: { padding: 4, marginLeft: 6 },
  forgotPassword: { alignSelf: 'flex-end', marginBottom: 6 },
  forgotPasswordText: { color: '#222', fontSize: 14, fontWeight: '500' },
  signInBtn: {
    backgroundColor: '#6B705B',
    borderRadius: 24,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 4,
    marginBottom: 4,
  },
  signInBtnText: { color: '#fff', fontSize: 18, fontWeight: '600' },
  biometricContainer: { alignItems: 'center', marginVertical: 10 },
  biometricBtn: {
    width: 70,
    height: 70,
    borderRadius: 50,
    backgroundColor: '#A3A38080',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
    borderWidth: 2,
    borderColor: '#6B705B',
  },
  biometricIcon: { width: 60, height: 60, resizeMode: 'contain' },
  biometricText: { color: '#6B705B', fontSize: 14, fontWeight: '500', marginTop: 2 },
  socialContainer: { marginTop: 4, marginBottom: 10 },
  socialBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#222',
    borderRadius: 24,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 8,
    backgroundColor: '#A3A38080',
  },
  socialIcon: { marginRight: 10 },
  socialBtnText: { color: '#222', fontSize: 16, fontWeight: '500' },
  footer: { alignItems: "center", marginBottom: 6 },
  footerText: { color: "#6B705B", fontSize: 16, textAlign: "center", opacity: 0.9 },
  footerLink: { color: '#6B705B', textDecorationLine: "underline", fontWeight: "bold" },
});
