import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  ScrollView,
  ActivityIndicator,
  KeyboardAvoidingView, // <-- add this
  Platform // <-- add this
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useTheme } from "../theme/ThemeContext";
import { useRouter } from "expo-router";
import { useState } from "react";
import PrimaryButton from "../components/PrimaryButton";
import TitleText from "../components/TitleText";
import SubText from "../components/SubText";
import { MaterialIcons } from '@expo/vector-icons';
import AnimatedBackground from "../components/AnimatedBackground";
import { toast } from 'sonner-native';

import { firebaseAuth } from '../config/firebase';
// Remove Firestore and Functions imports
// import { getFirestore, doc, setDoc, getDoc, deleteDoc } from 'firebase/firestore';
// import { getFunctions, httpsCallable } from 'firebase/functions';

const Signup = () => {
  const { theme } = useTheme();
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  // Remove Firestore and Functions initialization
  // const db = getFirestore();
  // const functions = getFunctions();
  // const sendOTPFunction = httpsCallable(functions, 'sendOTP');

  // Remove sendOTPEmail function

  // Validation function
  const validateForm = () => {
    const newErrors = {};

    // Email validation
    if (!email) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Please enter a valid email";
    }

    // Password validation
    if (!password) {
      newErrors.password = "Password is required";
    } else if (password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    // Confirm password validation
    if (!confirmPassword) {
      newErrors.confirmPassword = "Please confirm your password";
    } else if (password !== confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // New signup handler (no OTP)
  const handleSignup = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      if (!firebaseAuth) {
        throw new Error('Firebase is not properly initialized. Please check your configuration.');
      }
      const { createUserWithEmailAndPassword } = await import('firebase/auth');
      await createUserWithEmailAndPassword(firebaseAuth, email, password);
      toast('Signup successful! Please log in.');
      setTimeout(() => {
        router.push("/auth/login");
      }, 1200);
    } catch (error) {
      let errorMessage = "An error occurred during signup.";
      switch (error.code) {
        case 'auth/email-already-in-use':
          errorMessage = "This email is already registered. Please log in instead.";
          break;
        case 'auth/invalid-email':
          errorMessage = "Please enter a valid email address.";
          break;
        case 'auth/weak-password':
          errorMessage = "Password should be at least 6 characters.";
          break;
        case 'auth/network-request-failed':
          errorMessage = "Network error. Please check your internet connection.";
          break;
        default:
          errorMessage = error.message || errorMessage;
      }
      toast(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatedBackground>
      <SafeAreaView style={[styles.container]}>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
        >
          <ScrollView
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <View style={styles.innerContent}>
              <TitleText style={styles.title} title="Create an account" />
              <SubText style={styles.text} textContent="Welcome to Symptoms Diagnosis App" />
              <View style={styles.form}>
                <View style={styles.inputWrapper}>
                  <MaterialIcons name="email" size={24} color="#fff" style={styles.inputIcon} />
                  <TextInput
                    style={[styles.input, { color: theme.btnText }]}
                    placeholder="Email"
                    placeholderTextColor={theme.btnText}
                    value={email}
                    onChangeText={(text) => {
                      setEmail(text);
                      if (errors.email) setErrors({...errors, email: null});
                    }}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    editable={!loading}
                  />
                </View>
                {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}

                <View style={styles.inputWrapper}>
                  <MaterialIcons name="lock" size={24} color="#fff" style={styles.inputIcon} />
                  <TextInput
                    style={[styles.input, { color: theme.btnText }]}
                    placeholder="Password"
                    placeholderTextColor={theme.btnText}
                    value={password}
                    onChangeText={(text) => {
                      setPassword(text);
                      if (errors.password) setErrors({...errors, password: null});
                    }}
                    secureTextEntry={!showPassword}
                    autoCapitalize="none"
                    editable={!loading}
                  />
                  <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
                    <MaterialIcons name={showPassword ? "visibility" : "visibility-off"} size={24} color="#fff" />
                  </TouchableOpacity>
                </View>
                {errors.password && <Text style={styles.errorText}>{errors.password}</Text>}

                <View style={styles.inputWrapper}>
                  <MaterialIcons name="lock" size={24} color="#fff" style={styles.inputIcon} />
                  <TextInput
                    style={[styles.input, { color: theme.btnText }]}
                    placeholder="Re Type Password"
                    placeholderTextColor={theme.btnText}
                    value={confirmPassword}
                    onChangeText={(text) => {
                      setConfirmPassword(text);
                      if (errors.confirmPassword) setErrors({...errors, confirmPassword: null});
                    }}
                    secureTextEntry={!showConfirmPassword}
                    autoCapitalize="none"
                    editable={!loading}
                  />
                  <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)} style={styles.eyeIcon}>
                    <MaterialIcons name={showConfirmPassword ? "visibility" : "visibility-off"} size={24} color="#fff" />
                  </TouchableOpacity>
                </View>
                {errors.confirmPassword && <Text style={styles.errorText}>{errors.confirmPassword}</Text>}

                <View>
                  <PrimaryButton
                    title={loading ? "Signing up..." : "Sign Up"}
                    pressFunction={handleSignup}
                    style={[styles.emailBtn, { backgroundColor: theme.primaryBtnBg }]}
                    disabled={loading}
                  />
                  {loading && (
                    <View style={styles.loadingContainer}>
                      <ActivityIndicator size="small" color="#fff" />
                    </View>
                  )}
                </View>
              </View>
            </View>
            <View style={styles.footer}>
              <TouchableOpacity onPress={() => router.push("/auth/login")} disabled={loading}> 
                <Text style={styles.footerText}>
                  Already Have an Account? <Text style={styles.footerLink}>Sign In</Text>
                </Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default Signup;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollContent: { 
    flexGrow: 1, 
    justifyContent: "center", 
    padding: 20,
    paddingBottom: 40,
  },
  innerContent: { flex: 1, justifyContent: "center" },
  title: { textAlign: "center", marginBottom: 20 },
  text: { textAlign: "center", marginBottom: 40 },
  form: { gap: 18 },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(107, 112, 91, 0.5)",
    borderRadius: 24,
    paddingHorizontal: 18,
    marginBottom: 0,
  },
  inputIcon: { marginRight: 10 },
  input: {
    flex: 1,
    paddingVertical: 20,
    fontSize: 18,
  },
  eyeIcon: { padding: 4, marginLeft: 6 },
  emailBtn: { borderRadius: 24, marginTop: 18, paddingVertical: 20 },
  errorText: {
    color: '#ff6b6b',
    fontSize: 14,
    marginTop: 4,
    marginLeft: 18,
  },
  loadingContainer: {
    alignItems: 'center',
    marginTop: 10,
  },
  footer: { alignItems: "center", marginBottom: 20 },
  footerText: { color: "#363A3A", fontSize: 16, textAlign: "center", opacity: 0.9 },
  footerLink: { color: "#363A3A", textDecorationLine: "underline", fontWeight: "bold" },
});
