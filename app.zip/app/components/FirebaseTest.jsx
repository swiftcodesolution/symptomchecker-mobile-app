import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { firebaseAuth } from '../config/firebase';

const FirebaseTest = () => {
  const [status, setStatus] = useState('Testing...');

  useEffect(() => {
    const testFirebase = () => {
      try {
        console.log('Testing Firebase in component...');
        console.log('firebaseAuth:', firebaseAuth);
        
        if (firebaseAuth) {
          setStatus('✅ Firebase is initialized and ready!');
          console.log('✅ Firebase Auth is available');
        } else {
          setStatus('❌ Firebase Auth is null');
          console.log('❌ Firebase Auth is null');
        }
      } catch (error) {
        setStatus(`❌ Error: ${error.message}`);
        console.error('Firebase test error:', error);
      }
    };

    testFirebase();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.text}>{status}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#f0f0f0',
    margin: 10,
    borderRadius: 8,
  },
  text: {
    fontSize: 16,
    textAlign: 'center',
  },
});

export default FirebaseTest; 