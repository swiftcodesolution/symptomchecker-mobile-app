import React from "react";
import { Modal, View, Text, StyleSheet, TouchableOpacity } from "react-native";

const MedicationDetailsModal = ({ visible, medication, onClose }) => {
  if (!medication) return null;
  return (
    <Modal transparent visible={visible} animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.contentBox}>
          <View style={styles.headerRow}>
            <Text style={styles.title}>Medication Details</Text>
            <TouchableOpacity onPress={onClose}>
              <Text style={styles.closeBtn}>×</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.detailsRow}>
            <Text style={styles.label}>Name:</Text>
            <Text style={styles.value}>{medication.name}</Text>
          </View>
          <View style={styles.detailsRow}>
            <Text style={styles.label}>Dosage:</Text>
            <Text style={styles.value}>{medication.dosage}</Text>
          </View>
          <View style={styles.detailsRow}>
            <Text style={styles.label}>Frequency:</Text>
            <Text style={styles.value}>{medication.frequency}</Text>
          </View>
          <View style={styles.detailsRow}>
            <Text style={styles.label}>Time to take:</Text>
            <Text style={styles.value}>{medication.time}</Text>
          </View>
          <View style={styles.detailsRow}>
            <Text style={styles.label}>Refile Date:</Text>
            <Text style={styles.value}>{medication.refill}</Text>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(107, 112, 91, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  contentBox: {
    width: '90%',
    backgroundColor: '#7B7E6D',
    borderRadius: 36,
    padding: 28,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 8,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 18,
  },
  title: {
    fontSize: 32,
    color: '#24507A',
    fontWeight: '600',
  },
  closeBtn: {
    fontSize: 36,
    color: '#fff',
    marginLeft: 10,
    marginTop: -8,
  },
  detailsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  label: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 22,
    width: '50%',
  },
  value: {
    color: '#fff',
    fontSize: 22,
    width: '50%',
    textAlign: 'right',
  },
});

export default MedicationDetailsModal; 