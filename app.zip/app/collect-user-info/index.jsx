import { StyleSheet, Text, View, TextInput, TouchableOpacity, Alert, Animated, ScrollView, Platform, PermissionsAndroid, Modal } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useEffect, useRef } from "react";
import { useRouter } from "expo-router";
import { useTheme } from "../theme/ThemeContext";
import Icon from "react-native-vector-icons/Feather";
import * as Speech from 'expo-speech';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import AnimatedBackground from "../components/AnimatedBackground";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useVoiceRecognition } from '../hooks/useVoiceRecognition';
import {
  ExpoSpeechRecognitionModule,
  useSpeechRecognitionEvent,
} from "expo-speech-recognition";
import { useSelector, useDispatch } from 'react-redux';
import {
  setAnswer,
  setCurrentIndex,
  setIsListening,
  setTranscript,
  selectAnswers,
  selectCurrentIndex,
  selectIsListening,
  selectTranscript,
  resetUserInfo
} from '../redux/slices/userInfoSlice';


// Simple Web Speech API for web platform
const WebSpeechRecognition = {
  recognition: null,
  isAvailable: false,

  init: () => {
    if (Platform.OS === 'web') {
      if ('webkitSpeechRecognition' in window) {
        WebSpeechRecognition.recognition = new window.webkitSpeechRecognition();
        WebSpeechRecognition.isAvailable = true;
      } else if ('SpeechRecognition' in window) {
        WebSpeechRecognition.recognition = new window.SpeechRecognition();
        WebSpeechRecognition.isAvailable = true;
      }

      if (WebSpeechRecognition.isAvailable) {
        WebSpeechRecognition.recognition.continuous = false;
        WebSpeechRecognition.recognition.interimResults = false;
        WebSpeechRecognition.recognition.lang = 'en-US';
        console.log('Web Speech API initialized');
      }
    }
  },

  start: (onResult, onError) => {
    if (!WebSpeechRecognition.isAvailable) {
      if (onError) onError('Speech recognition not available');
      return;
    }

    WebSpeechRecognition.recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      if (onResult) onResult(transcript);
    };

    WebSpeechRecognition.recognition.onerror = (event) => {
      if (onError) onError(event.error);
    };

    WebSpeechRecognition.recognition.start();
  },

  stop: () => {
    if (WebSpeechRecognition.recognition) {
      WebSpeechRecognition.recognition.stop();
    }
  }
};

// Initialize Web Speech API
WebSpeechRecognition.init();

export const questionsData = [
  {
    question: "What is your Full Name?",
    summarizedAnswer: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
  },
  {
    question: "What your Date of Birth?",
    summarizedAnswer: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
  },
  {
    question: "Have you had any surgeries in the past?",
    summarizedAnswer: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
  },
];

const CollectUserInfo = () => {
  const [userAnswers, setUserAnswers] = useState({});
  const answers = useSelector(selectAnswers);
  const currentIndex = useSelector(selectCurrentIndex);
  const isListening = useSelector(selectIsListening);
  const transcript = useSelector(selectTranscript);
  const [isPaused, setIsPaused] = useState(false);
  const dispatch = useDispatch();

  const pulseAnim = useRef(new Animated.Value(1)).current;
  const { theme } = useTheme();
  const router = useRouter();

  // Inside your CollectUserInfo component:
  useEffect(() => {
    // Reset state when component mounts
    dispatch(resetUserInfo());
  }, [dispatch]);

  // Use the native voice recognition hook
  const {
    error,
    startRecording,
    stopRecording,
    isAvailable
  } = useVoiceRecognition();

  // Debug logging
  console.log('=== COLLECT USER INFO DEBUG ===');
  console.log('isAvailable:', isAvailable);
  console.log('isListening:', isListening);
  console.log('transcript:', transcript);
  console.log('error:', error);



  // Animation for mic button
  useEffect(() => {
    if (isListening) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.2,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isListening]);

  // Update answer when transcript is received
  useEffect(() => {
    if (transcript) {
      dispatch(setAnswer({
        index: currentIndex,
        answer: transcript,
        summarizedAnswer: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
      }));
    }
  }, [transcript]);

  useEffect(() => {
    const currentAnswer = answers[currentIndex]?.answer || '';
    dispatch(setTranscript(currentAnswer));
  }, [currentIndex]);

  // Handle errors
  useEffect(() => {
    if (error) {
      Alert.alert('Voice Recognition Error', error);
    }
  }, [error]);

  // Request microphone permissions for Android
  const requestMicrophonePermission = async () => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
          {
            title: 'Microphone Permission',
            message: 'This app needs access to your microphone for voice recognition.',
            buttonNeutral: 'Ask Me Later',
            buttonNegative: 'Cancel',
            buttonPositive: 'OK',
          }
        );
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      } catch (err) {
        console.warn(err);
        return false;
      }
    }
    return true;
  };

  const [recognizing, setRecognizing] = useState(false);

  useSpeechRecognitionEvent("start", () => setRecognizing(true));
  useSpeechRecognitionEvent("end", () => setRecognizing(false));
  useSpeechRecognitionEvent("result", (event) => {
    if (event.results && event.results[0]) {
      const newTranscript = event.results[0]?.transcript;
      dispatch(setTranscript(newTranscript));
      dispatch(setAnswer({
        index: currentIndex,
        answer: newTranscript,
        summarizedAnswer: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
      }));
    }
  });
  useSpeechRecognitionEvent("error", (event) => {
    console.log("error code:", event.error, "error message:", event.message);
    Alert.alert('Error', 'Voice recognition failed');
    dispatch(setIsListening(false));
  });

  // Simple voice recognition handler
  const handleMicPress = async () => {
    console.log('=== MIC PRESSED ===');
    console.log('Platform:', Platform.OS);
    console.log('isListening:', isListening);
    console.log('isAvailable:', isAvailable);

    if (Platform.OS === 'web' && WebSpeechRecognition.isAvailable) {
      console.log('Using Web Speech API');
      if (isListening) {
        if (isPaused) {
          // Resume recording
          WebSpeechRecognition.start(
            (transcript) => {
              console.log('Voice to text:', transcript);
              setAnswer(transcript);
              setIsListening(false);
            },
            (error) => {
              console.log('Speech recognition error:', error);
              setIsListening(false);
              Alert.alert('Error', 'Voice recognition failed. Please try again.');
            }
          );
          setIsPaused(false);
        } else {
          // Pause recording
          WebSpeechRecognition.stop();
          setIsPaused(true);
        }
      } else {
        setIsPaused(false);
        WebSpeechRecognition.start(
          (transcript) => {
            console.log('Voice to text:', transcript);
            setAnswer(transcript);
            setIsListening(false);
          },
          (error) => {
            console.log('Speech recognition error:', error);
            setIsListening(false);
            Alert.alert('Error', 'Voice recognition failed. Please try again.');
          }
        );
      }
    } else if (Platform.OS === 'android') {
      // Handle Android specifically
      try {
        const result = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
        if (!result.granted) {
          console.warn("Permissions not granted", result);
          return;
        }

        if (isListening) {
          ExpoSpeechRecognitionModule.stop()
          dispatch(setIsListening(false));
          setIsPaused(false);
          // await stopRecording();
        } else {
          dispatch(setIsListening(true));
          setIsPaused(false);
          ExpoSpeechRecognitionModule.start({
            lang: "en-US",
            interimResults: true,
            continuous: true,
          });
          setIsPaused(false);
        }
      } catch (err) {
        console.error('Voice recognition error:', err);
        Alert.alert('Error', 'Failed to start voice recognition');
        dispatch(setIsListening(false));
        setIsPaused(false);
      }
    } else {
      // Fallback for devices without voice recognition
      console.log('Voice recognition not available');
      Alert.alert('Voice Recognition', 'Voice recognition not available. Please type your answer.');
    }
  };



  const handlePressNext = () => {
    // Save current answer
    if (transcript.trim()) {
      dispatch(setAnswer({
        index: currentIndex,
        answer: transcript,
        summarizedAnswer: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
      }));
    }

    if (currentIndex < questionsData.length - 1) {
      dispatch(setCurrentIndex(currentIndex + 1));
      dispatch(setTranscript(""));
    } else {
      // Save all answers and navigate to recap
      const finalAnswers = {
        ...userAnswers,
        [currentIndex]: transcript.trim()
      };

      // Save to AsyncStorage
      AsyncStorage.setItem('userPersonalInfo', JSON.stringify(finalAnswers))
        .then(() => {
          router.push("/collect-user-info/recap");
        })
        .catch(error => {
          console.log('Error saving user info:', error);
          router.push("/collect-user-info/recap");
        });
    }
  };

  const handlePressSkip = () => {
    console.log('Skip button pressed');
    console.log('Current index:', currentIndex);

    if (currentIndex < questionsData.length - 1) {
      console.log('Moving to next question');
      dispatch(setCurrentIndex(currentIndex + 1));
      dispatch(setTranscript(""));
    } else {
      console.log('Navigating to recap');
      // ... rest of the code
    }
  };

  return (
    <AnimatedBackground>
      <SafeAreaView style={styles.container}>
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Top Card: Question */}
          <View style={styles.card}>
            {/* Progress Dots */}
            <View style={styles.progressRow}>
              {questionsData.map((_, idx) => (
                <View
                  key={idx}
                  style={[styles.dot, idx === currentIndex && styles.dotActive]}
                />
              ))}
            </View>
            <View style={styles.circleNum}><Text style={styles.circleNumText}>{currentIndex + 1}</Text></View>
            <Text style={styles.questionText}>{questionsData[currentIndex].question}</Text>
            {/* Input Row: input + send in one group, mic outside */}
            <View style={{ flexDirection: 'row', alignItems: 'center', width: '100%' }}>
              <View style={styles.inputGroup}>
                <TextInput
                  style={styles.input}
                  placeholder="Type your answer"
                  placeholderTextColor="#fff"
                  value={transcript}
                  onChangeText={(text) => dispatch(setTranscript(text))}
                />
                <TouchableOpacity style={styles.iconBtn} onPress={handlePressNext}>
                  <Icon name="send" size={22} color="#fff" />
                </TouchableOpacity>
              </View>
              <View style={{ alignItems: 'center' }}>
                <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
                  <TouchableOpacity
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 40,
                      backgroundColor: isListening ? '#ff4444' : (isAvailable ? '#6B705B' : '#bfc2c6'),
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginLeft: 8,
                    }}
                    onPress={handleMicPress}
                    activeOpacity={0.7}
                    disabled={!isAvailable}
                  >
                    <MaterialCommunityIcons
                      name={
                        isListening ? "microphone" :
                          isPaused ? "microphone-off" :
                            "microphone-outline"
                      }
                      size={30}
                      color="#fff"
                    />
                  </TouchableOpacity>
                </Animated.View>
                {isListening && (
                  <Text style={{ color: '#ff4444', fontWeight: 'bold', marginTop: 4, fontSize: 12 }}>
                    Listening...
                  </Text>
                )}
              </View>
            </View>
            {isListening ? (
              <Text style={{ color: '#ff4444', fontWeight: 'bold', marginTop: 4, fontSize: 12 }}>
                Listening... Tap to stop
              </Text>
            ) : (
              <Text style={{ color: '#6B705B', fontWeight: '500', marginTop: 4, fontSize: 12 }}>
                {isAvailable ? 'Tap to speak' : 'Voice not available'}
              </Text>
            )}
            {!isListening && (
              <Text style={styles.disabledText}>
                {Platform.OS === 'web'
                  ? 'Tap mic to start voice recognition'
                  : isAvailable
                    ? 'Tap mic to record your voice'
                    : 'Voice recognition not available'}
              </Text>
            )}
          </View>
          {/* Bottom Card: Summary */}
          <View style={styles.card}>
            <Text style={styles.summaryTitle}>Your summarized answer.</Text>
            <Text style={styles.summaryText}>{questionsData[currentIndex].summarizedAnswer}</Text>
            <View style={styles.progressRow}>
              {questionsData.map((_, idx) => (
                <View
                  key={idx}
                  style={[styles.dot, idx === currentIndex && styles.dotActive]}
                />
              ))}
            </View>
            <View style={styles.buttonRow}>
              <TouchableOpacity style={styles.nextBtn} onPress={handlePressNext}>
                <Text style={styles.nextBtnText}>{currentIndex === questionsData.length - 1 ? 'Finish' : 'Next'}</Text>
              </TouchableOpacity>
              {currentIndex < questionsData.length - 1 && (
                <TouchableOpacity style={styles.skipBtn} onPress={handlePressSkip}>
                  <Text style={styles.skipBtnText}>Skip</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default CollectUserInfo;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollContent: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 0,
    paddingBottom: 40,
  },
  card: {
    width: '90%',
    backgroundColor: '#e2ded6',
    borderRadius: 32,
    paddingVertical: 32,
    paddingHorizontal: 24,
    marginBottom: 24,
    alignItems: 'flex-start',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 4,
  },
  progressRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 18,
    marginTop: 0,
  },
  dot: {
    width: 24,
    height: 8,
    borderRadius: 8,
    backgroundColor: '#bfc2c6',
  },
  dotActive: {
    backgroundColor: '#6B705B',
  },
  circleNum: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#6B705B',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
  },
  circleNumText: {
    color: '#fff',
    fontSize: 22,
    fontWeight: '600',
  },
  questionText: {
    fontSize: 32,
    fontWeight: '500',
    color: '#222',
    marginBottom: 24,
  },
  inputGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#BFC2B7',
    borderRadius: 24,
    flex: 1,
    height: 56,
    marginRight: 12,
    paddingLeft: 18,
  },
  input: {
    flex: 1,
    fontSize: 18,
    color: '#fff',
    paddingVertical: 16,
    backgroundColor: 'transparent',
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#6B705B',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  summaryTitle: {
    fontSize: 28,
    fontWeight: '500',
    color: '#222',
    marginBottom: 10,
  },
  summaryText: {
    fontSize: 20,
    color: '#222',
    marginBottom: 24,
  },
  buttonRow: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    marginTop: 18,
    gap: 12,
  },
  nextBtn: {
    flex: 1,
    backgroundColor: '#6B705B',
    borderRadius: 20,
    alignItems: 'center',
    paddingVertical: 16,
    marginRight: 8,
  },
  nextBtnText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '500',
  },
  skipBtn: {
    flex: 1,
    backgroundColor: '#B6BDC6',
    borderRadius: 20,
    alignItems: 'center',
    paddingVertical: 16,
    marginLeft: 8,
  },
  skipBtnText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '500',
  },
  listeningText: {
    color: '#6B705B',
    fontSize: 16,
    fontWeight: '500',
    marginTop: 8,
    textAlign: 'center',
  },
  disabledText: {
    color: '#6B705B',
    fontSize: 14,
    fontWeight: '500',
    marginTop: 8,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});
