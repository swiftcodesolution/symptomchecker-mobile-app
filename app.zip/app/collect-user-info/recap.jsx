import { StyleSheet, View, ScrollView, Text } from "react-native";
import RecapCard from "../components/RecapCard";
import { questionsData } from "./index";
import { SafeAreaView } from "react-native-safe-area-context";
import { useTheme } from "../theme/ThemeContext";
import TitleText from "../components/TitleText";
import SubText from "../components/SubText";
import PrimaryButton from "../components/PrimaryButton";
import { useRouter } from "expo-router";
import AnimatedBackground from "../components/AnimatedBackground";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useState, useEffect } from "react";
import { useSelector, useDispatch } from 'react-redux';
import { selectAnswers } from "../redux/slices/userInfoSlice";
import { setCurrentIndex } from "../redux/slices/userInfoSlice";
import { firebaseAuth, firestore } from '../config/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { toast } from 'sonner-native';

const Recap = () => {
  const { theme } = useTheme();
  const router = useRouter();
  const [userAnswers, setUserAnswers] = useState({});
  const [loading, setLoading] = useState(true);
  const answerss = useSelector(selectAnswers);
  const dispatch = useDispatch();
    

  useEffect(() => {
    const loadUserAnswers = async () => {
      try {
        const savedAnswers = await AsyncStorage.getItem('userPersonalInfo');
        if (savedAnswers) {
          setUserAnswers(JSON.parse(savedAnswers));
        }
      } catch (error) {
        console.error('Error loading user answers:', error);
      } finally {
        setLoading(false);
      }
    };

    loadUserAnswers();
  }, []);

  // Create answers array based on actual user data
  const answers = questionsData.map((question, index) => {
    const answerItem = answerss[index] || {};
    
    return {
      question: answerItem.answer,
      hasAnswer: !!answerItem.answer && answerItem.answer.trim() !== '',
      answer: answerItem.answer || '',
      summarizedAnswer: answerItem.summarizedAnswer || ''
    };
  });

  const editAnswer = (index) => {
    dispatch(setCurrentIndex(index));
    router.push("/collect-user-info");
  };

  const handleDone = async () => {
    try {
      setLoading(true);
      
      // Get current authenticated user
      const user = firebaseAuth.currentUser;
      if (!user) {
        throw new Error('User not authenticated');
      }

      const cleanedAnswers = answerss.map(answer => ({
        answer: answer?.answer || '',
        summarizedAnswer: answer?.summarizedAnswer || ''
      }));

      const hasEmptyAnswers = cleanedAnswers.some(item => !item.answer.trim());
      if (hasEmptyAnswers) {
        throw new Error('Please fill all required fields');
      }

      // Prepare data for Firestore
      const userData = {
        answers: cleanedAnswers,
        completedAt: new Date().toISOString(),
        userId: user.uid,
        email: user.email || ''
      };


      // Save to Firestore
      const userDocRef = doc(firestore, 'users', user.uid);
      await setDoc(userDocRef, userData, { merge: true });

      // Mark as completed in AsyncStorage
      await AsyncStorage.setItem('personalInfo', 'completed');
      
      toast('Your information has been saved successfully!');
      router.push("/(main)");
      
    } catch (error) {
      console.error('Error saving personal info:', error);
      toast('Failed to save your information. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // if (loading) {
  //   return (
  //     <AnimatedBackground>
  //       <SafeAreaView style={[styles.container, { backgroundColor: 'transparent' }]}>
  //         <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
  //           <Text style={{ fontSize: 18, color: '#6B705B' }}>Loading your information...</Text>
  //         </View>
  //       </SafeAreaView>
  //     </AnimatedBackground>
  //   );
  // }

  return (
    <AnimatedBackground>
      <SafeAreaView
        style={[styles.container, { backgroundColor: 'transparent' }]}
      >
        <View>
          <TitleText style={styles.title} title="Recap" />
          <SubText
            style={styles.text}
            textContent="Thank you for providing your medical details. Please review them and make any necessary corrections."
          />
        </View>
        <ScrollView style={styles.scrollView} contentContainerStyle={{ gap: 18 }}>
          <View style={styles.recapCards}>
            {answers.map((item, index) => (
              <RecapCard
                key={index}
                question={item.question}
                hasAnswer={item.hasAnswer}
                editAnswer={() => editAnswer(index)}
                buttonLabel={item.hasAnswer ? "Edit" : "Reply"}
              />
            ))}
          </View>
        </ScrollView>
        <View>
          <PrimaryButton
            title={loading ? "Saving..." : "Done"}
            pressFunction={handleDone}
            style={[styles.emailBtn, { backgroundColor: theme.primaryBtnBg }]}
            disabled={loading}
          />
        </View>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default Recap;

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", gap: 40, padding: 20 },
  title: { textAlign: "center", marginBottom: 20 },
  text: { textAlign: "center", marginBottom: 0 },

  scrollView: {},
  recapCards: { gap: 18, marginVertical: 20 },
});
