import { useState, useEffect } from 'react';
import { Platform, PermissionsAndroid, Alert, NativeModules } from 'react-native';

// Real voice recognition using Android's native speech recognition
const VoiceRecognition = {
  isAvailable: true,
  
  requestPermission: async () => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
          {
            title: 'Microphone Permission',
            message: 'This app needs access to your microphone for voice recognition.',
            buttonNeutral: 'Ask Me Later',
            buttonNegative: 'Cancel',
            buttonPositive: 'OK',
          }
        );
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      } catch (err) {
        console.warn(err);
        return false;
      }
    }
    return true;
  },

  start: async () => {
    if (Platform.OS === 'android') {
      try {
        const { SpeechRecognition } = NativeModules;
        
        if (SpeechRecognition) {
          return new Promise((resolve, reject) => {
            SpeechRecognition.startRecognition()
              .then((result) => {
                console.log('Speech recognition result:', result);
                resolve(result);
              })
              .catch((error) => {
                console.error('Speech recognition error:', error);
                reject(error);
              });
          });
        } else {
          throw new Error('Speech recognition module not available');
        }
      } catch (error) {
        console.error('Speech recognition error:', error);
        throw error;
      }
    }
  },

  stop: async () => {
    if (Platform.OS === 'android') {
      try {
        const { SpeechRecognition } = NativeModules;
        if (SpeechRecognition) {
          await SpeechRecognition.stopRecognition();
        }
      } catch (error) {
        console.error('Error stopping speech recognition:', error);
      }
    }
  }
};

export const useVoiceRecognition = () => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState(null);

  const startRecording = async () => {
    try {
      setError(null);
      setTranscript('');
      
      if (Platform.OS === 'android') {
        const hasPermission = await VoiceRecognition.requestPermission();
        if (!hasPermission) {
          throw new Error('Microphone permission denied');
        }
        
        setIsListening(true);
        
        const result = await VoiceRecognition.start();
        setTranscript(result);
        setIsListening(false);
        
      } else {
        throw new Error('Voice recognition not available on this platform');
      }
    } catch (err) {
      console.error('Error starting voice recognition:', err);
      setError(err.message);
      setIsListening(false);
      
      // Show fallback message if native modules are not available
      Alert.alert(
        'Voice Recognition',
        'Real voice recognition requires additional setup. For now, this is a demo.',
        [
          {
            text: 'OK',
            onPress: () => {
              setTimeout(() => {
                setTranscript('This is demo text. Real voice recognition would capture your actual speech.');
                setIsListening(false);
              }, 2000);
            }
          }
        ]
      );
    }
  };

  const stopRecording = async () => {
    try {
      await VoiceRecognition.stop();
      setIsListening(false);
    } catch (err) {
      console.error('Error stopping voice recognition:', err);
    }
  };

  return {
    isListening,
    transcript,
    error,
    startRecording,
    stopRecording,
    isAvailable: Platform.OS === 'android' && VoiceRecognition.isAvailable
  };
}; 