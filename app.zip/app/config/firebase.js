import { initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Firebase configuration for React Native
const firebaseConfig = {
  apiKey: "AIzaSyBmEQNyMOt6rBr6R-cC8XbV-TRO1i8-x90",
  authDomain: "ai-boat-341cf.firebaseapp.com",
  projectId: "ai-boat-341cf",
  storageBucket: "ai-boat-341cf.firebasestorage.app",
  messagingSenderId: "749534211951",
  appId: "1:749534211951:android:cfdd80fe6db9de4e2c829a",
  // Add clientId for web compatibility (optional)
  clientId: "749534211951-google-signin-client-id"
};

console.log('Firebase config:', firebaseConfig);

// Initialize Firebase
let app = null;
let firebaseAuth = null;

try {
  console.log('Initializing Firebase...');
  app = initializeApp(firebaseConfig);
  console.log('Firebase app initialized successfully');
  
  // Initialize Auth with persistence for React Native
  try {
    firebaseAuth = initializeAuth(app, {
      persistence: getReactNativePersistence(AsyncStorage)
    });
    console.log('Firebase Auth initialized with persistence');
  } catch (authError) {
    console.log('Failed to initialize Auth with persistence, using fallback:', authError);
    firebaseAuth = getAuth(app);
    console.log('Firebase Auth initialized without persistence');
  }
  
  // Test if auth is working
  if (firebaseAuth) {
    console.log('Firebase Auth is ready to use');
    console.log('Auth instance:', firebaseAuth);
  } else {
    console.error('Firebase Auth is null after initialization');
  }
  
} catch (error) {
  console.error('Firebase initialization error:', error);
  console.error('Error details:', error.message);
  console.error('Error stack:', error.stack);
}

// Initialize Firestore
let firestore = null;

try {
  firestore = getFirestore(app);
  console.log('Firestore initialized successfully');
} catch (error) {
  console.error('Firestore initialization error:', error);
}

// Export with null checks
export { app, firebaseAuth, firestore };
export default { app, firebaseAuth, firestore }; 