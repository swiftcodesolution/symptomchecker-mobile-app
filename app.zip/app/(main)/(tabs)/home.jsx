import Dashboard from '../index';

export default function HomeScreen() {
  return <Dashboard />;
} 