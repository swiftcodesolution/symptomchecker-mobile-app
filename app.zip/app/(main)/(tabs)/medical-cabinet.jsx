import { ScrollView, StyleSheet, Text, View, Image, Switch, TouchableOpacity } from "react-native";
import { useTheme } from "../../theme/ThemeContext";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader from "../../components/CustomHeader";
import SubText from "../../components/SubText";
import SmallButton from "../../components/SmallButton";
import TitleText from "../../components/TitleText";
import ThreeColumnBox from "../../components/ThreeColumnBox";
import TwoColumnBox from "../../components/TwoColumnBox";
import { useState } from "react";
import MedicalModal from "../../components/MedicalModal";
import MedicationDetailsModal from "../../components/MedicationDetailsModal";
import { useNavigation } from "@react-navigation/native";
import Icon from "react-native-vector-icons/Feather";
import AnimatedBackground from "../../components/AnimatedBackground";
import Header from "../../components/Header";

const profileImg = require("../../../assets/user.jpg");

const MedicalCabinet = () => {
  const { theme } = useTheme();
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [selectedMedication, setSelectedMedication] = useState(null);
  const [detailsModalVisible, setDetailsModalVisible] = useState(false);

  const openModal = () => {
    setModalVisible(true);
    console.log("gggg");
  };
  const closeModal = () => {
    setModalVisible(false);
  };

  const handlePress = () => {
    console.log(`btn pressed!`);
  };

  // Dummy medication data
  const medications = [
    { name: "Flagel", dosage: "200 ml", frequency: "2", time: "1 PM", refill: "DD/MM/YYYY" },
    { name: "Flagel", dosage: "200 ml", frequency: "2", time: "1 PM", refill: "DD/MM/YYYY" },
    { name: "Flagel", dosage: "200 ml", frequency: "2", time: "1 PM", refill: "DD/MM/YYYY" },
  ];

  return (
    <AnimatedBackground>
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView 
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <Header
            profileImage={profileImg}
            greeting="Hello Scott"
            location="SC, 702 USA"
            sos={true}
          />
          
          <Text style={styles.pageTitle}>Medicine Cabinet</Text>
          {/* Enable Notifications */}
          <View style={styles.notificationRow}>
            <Text style={styles.enableNotifText}>Enable Notifications</Text>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              thumbColor={notificationsEnabled ? '#6B705B' : '#ccc'}
              trackColor={{ false: '#ccc', true: '#A3A380' }}
            />
          </View>
          {/* Medication List Section */}
          <View style={{paddingHorizontal: 18}}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionHeader}>Medication List</Text>
            <SmallButton btnText="See All" pressFunction={() => {}} style={styles.seeAllBtn} />
          </View>
          <View style={styles.medListTable}>
            <View style={styles.tableHeaderRow}>
              <Text style={styles.tableHeader}>Name</Text>
              <Text style={styles.tableHeader}>Dosage</Text>
              <Text style={styles.tableHeader}>Frequency</Text>
            </View>
            {medications.map((med, idx) => (
              <TouchableOpacity
                style={styles.tableRow}
                key={idx}
                onPress={() => {
                  setSelectedMedication(med);
                  setDetailsModalVisible(true);
                }}
                activeOpacity={0.7}
              >
                <Text style={styles.tableCell}>{med.name}</Text>
                <Text style={styles.tableCell}>{med.dosage}</Text>
                <Text style={styles.tableCell}>{med.frequency}</Text>
              </TouchableOpacity>
            ))}
          </View>
          </View>
        </ScrollView>
        <MedicationDetailsModal
          visible={detailsModalVisible}
          medication={selectedMedication}
          onClose={() => setDetailsModalVisible(false)}
        />
      </SafeAreaView>

      <MedicalModal visible={modalVisible} onClose={closeModal} />
    </AnimatedBackground>
  );
};

export default MedicalCabinet;

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 40,
    marginBottom: 50,
    // position: 'relative',
  },
  profileWrapper: {
    position: "absolute",
    left: 0,
    right: 0,
    alignItems: "center",
    zIndex: 2,
  },
  menuBtn: {
    width: 48,
    height: 48,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 16,
    backgroundColor: "#F3EFE6",
    zIndex:9999999999
  },
  menuIconBox: { flex: 1, alignItems: 'flex-start' },
  menuIcon: {
    width: 40, height: 40, backgroundColor: '#EFEDE7', borderRadius: 12, opacity: 0.7,
  },
  profileImg: {
    width: 90, height: 90, borderRadius: 45, borderWidth: 4, borderColor: '#fff', marginTop: 10,
  },
  sosBox: { flex: 1, alignItems: 'flex-end' },
  sosButton: {
    backgroundColor: '#E63946',
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 10,
    marginRight: 2,
    marginTop: 2,
  },
  sosText: { color: '#fff', fontWeight: 'bold', fontSize: 18 },
  helloText: {
    textAlign: 'center',
    fontSize: 44,
    color: '#495057',
    fontWeight: '400',
    marginTop: 10,
    letterSpacing: 1,
  },
  locationText: {
    textAlign: 'center',
    color: '#6B705B',
    fontSize: 16,
    marginBottom: 18,
    opacity: 0.7,
  },
  pageTitle: {
    textAlign: 'center',
    fontSize: 32,
    color: '#6B705B',
    fontWeight: '400',
    marginBottom: 18,
  },
  notificationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
    gap: 10,
  },
  enableNotifText: {
    color: '#24507A',
    fontSize: 18,
    fontWeight: '500',
    marginRight: 10,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 10,
    marginBottom: 10,
    paddingHorizontal: 2,
  },
  sectionHeader: {
    color: '#24507A',
    fontSize: 32,
    fontWeight: '600',
  },
  seeAllBtn: {
    marginLeft: 10,
  },
  medListTable: {
    backgroundColor: '#E9E9E0',
    borderRadius: 24,
    padding: 10,
    marginHorizontal: 2,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  tableHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#E5DED6',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingVertical: 10,
    paddingHorizontal: 8,
  },
  tableHeader: {
    flex: 1,
    color: '#6B705B',
    fontWeight: '600',
    fontSize: 20,
    textAlign: 'left',
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#D6D6CE',
  },
  tableCell: {
    flex: 1,
    color: '#495057',
    fontSize: 18,
    textAlign: 'left',
  },
});
