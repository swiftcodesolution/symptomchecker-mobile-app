import { ScrollView, StyleSheet, Text, View, Image, TouchableOpacity, Animated, Easing } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader from "../../components/CustomHeader";
import TitleText from "../../components/TitleText";
import SubText from "../../components/SubText";
import SmallButton from "../../components/SmallButton";
import ThreeColumnBox from "../../components/ThreeColumnBox";
import { useTheme } from "../../theme/ThemeContext";
import DetailsCard from "../../components/DetailsCard";
import PharmacyList from "../../components/PharmacyList";
import Icon from "react-native-vector-icons/Feather";
import { useNavigation } from '@react-navigation/native';
import AnimatedBackground from "../../components/AnimatedBackground";
import Header from "../../components/Header";
import { useState, useRef, useEffect } from "react";

const profileImg = require("../../../assets/user.jpg");
const HEADER_HEIGHT = 300; // Match search-history

const MedicalWallet = () => {
  const { theme } = useTheme();
  const navigation = useNavigation();
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const lastScrollY = useRef(0);
  const anim = useRef(new Animated.Value(0)).current;

  // Animate header in/out
  const animateHeader = (show) => {
    Animated.timing(anim, {
      toValue: show ? 0 : -HEADER_HEIGHT,
      duration: 350,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  };

  // Scroll handler
  const handleScroll = (event) => {
    const currentY = event.nativeEvent.contentOffset.y;
    const delta = currentY - lastScrollY.current;
    if (Math.abs(delta) < 10) return;
    if (delta > 0 && isHeaderVisible && currentY > 40) {
      setIsHeaderVisible(false);
      animateHeader(false);
    } else if (delta < 0 && !isHeaderVisible && currentY < 60) {
      setIsHeaderVisible(true);
      animateHeader(true);
    }
    lastScrollY.current = currentY;
  };

  const handlePress = () => {
    console.log(`btn pressed!`);
  };

  return (
    <AnimatedBackground>
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.contentSection}>
          <Animated.View
            style={[
              styles.animatedContent,
              {
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                marginLeft: "5%",
                transform: [{ translateY: anim }],
                opacity: anim.interpolate({
                  inputRange: [-HEADER_HEIGHT, 0],
                  outputRange: [0, 1],
                }),
              },
            ]}
          >
            <Header
              profileImage={profileImg}
              greeting="Hello Scott"
              location="SC, 702 USA"
              sos={true}
            />
            <Text style={styles.pageTitle}>Medical Wallet</Text>
          </Animated.View>
          <View style={styles.listWrapper}>
            <ScrollView
              style={[styles.scrollViewStyles]}
              contentContainerStyle={styles.scrollViewStylesInner}
              showsVerticalScrollIndicator={false}
              onScroll={handleScroll}
              scrollEventThrottle={16}
            >
              <View style={styles.contentPadding}>
                {/* Personal Details Card */}
                <View style={[styles.card,{marginTop: HEADER_HEIGHT}]}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Personal Details</Text>
                    <SmallButton btnText="Edit" pressFunction={handlePress} />
                  </View>
                  {/* Example content, replace with DetailsCard if needed */}
                  <View style={styles.detailsContent}>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Name:</Text><Text style={styles.detailValue}>Scott</Text><Text style={styles.bloodGroup}>Blood Group: O+</Text></View>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Contact No:</Text><Text style={styles.detailValue}>+12134123</Text></View>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Address:</Text><Text style={styles.detailValue}>Park Avenue, Sc US</Text></View>
                  </View>
                </View>

                {/* Insurance Details Card */}
                <View style={styles.card}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Insurance Details</Text>
                    <SmallButton btnText="Detail" pressFunction={handlePress} />
                  </View>
                  <View style={styles.detailsContent}>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Company Name:</Text><Text style={styles.detailValue}>Scott</Text></View>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Policy No:</Text><Text style={styles.detailValue}>123-12</Text></View>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Cont Person Name:</Text><Text style={styles.detailValue}>Adam</Text></View>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Cont Person No:</Text><Text style={styles.detailValue}>+123435423</Text></View>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Issue Date:</Text><Text style={styles.detailValue}>22-21-25</Text><Text style={styles.detailLabel}>Expiry Date:</Text><Text style={styles.detailValue}>22-21-25</Text></View>
                  </View>
                </View>

                {/* Doctor Details Card */}
                <View style={styles.card}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Doctor Details</Text>
                    <SmallButton btnText="Edit" pressFunction={handlePress} />
                  </View>
                  <View style={styles.detailsContent}>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Doctor Name:</Text><Text style={styles.detailValue}>Scott</Text></View>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Phone No:</Text><Text style={styles.detailValue}>+12134123</Text></View>
                    <View style={styles.detailRow}><Text style={styles.detailLabel}>Email- Address:</Text><Text style={styles.detailValue}>Park Avenue, Sc US</Text></View>
                  </View>
                </View>

                {/* Personal Contacts Table */}
                <View style={styles.card}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Personal Contacts</Text>
                    <SmallButton btnText="Manage" pressFunction={handlePress} />
                  </View>
                  <View style={styles.tableHeaderRow}>
                    <Text style={styles.tableHeader}>Name</Text>
                    <Text style={styles.tableHeader}>Relation</Text>
                    <Text style={styles.tableHeader}>Contact</Text>
                  </View>
                  <View style={styles.tableRow}><Text style={styles.tableCell}>Alex</Text><Text style={styles.tableCell}>Father</Text><Text style={styles.tableCell}>+12134123</Text></View>
                  <View style={styles.tableRow}><Text style={styles.tableCell}>Scott</Text><Text style={styles.tableCell}>Son</Text><Text style={styles.tableCell}>+12134123</Text></View>
                  <View style={styles.tableRow}><Text style={styles.tableCell}>Bart</Text><Text style={styles.tableCell}>Friend</Text><Text style={styles.tableCell}>2</Text></View>
                </View>

                {/* Preferred Pharmacy */}
                <View style={styles.card}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Preferred Pharmacy</Text>
                    <SmallButton btnText="See All" pressFunction={handlePress} />
                  </View>
                  <View style={styles.pharmacyRow}>
                    <View style={styles.pharmacyCard}>
                      <Image source={require('../../../assets/pharmacy-logo.png')} style={styles.pharmacyLogo} />
                      <Text style={styles.pharmacyName}>Adam Medic</Text>
                      <Text style={styles.pharmacyAddress}>Daz Street bay zone SC, US</Text>
                    </View>
                    <View style={[styles.pharmacyCard, styles.addPharmacyCard]}>
                      <Text style={styles.addPharmacyText}>+</Text>
                    </View>
                  </View>
                </View>

                {/* Nearby Pharmacy */}
                <View style={styles.card}>
                  <View style={styles.titleBox}>
                    <Text style={styles.sectionHeading}>Nearby Pharmacy</Text>
                    <SmallButton btnText="See All" pressFunction={handlePress} />
                  </View>
                  <View style={styles.pharmacyRow}>
                    <View style={styles.pharmacyCard}>
                      <Image source={require('../../../assets/pharmacy-logo.png')} style={styles.pharmacyLogo} />
                      <Text style={styles.pharmacyName}>Adam Medic</Text>
                      <Text style={styles.pharmacyAddress}>Daz Street bay zone SC, US</Text>
                    </View>
                    <View style={styles.pharmacyCard}>
                      <Image source={require('../../../assets/pharmacy-logo.png')} style={styles.pharmacyLogo} />
                      <Text style={styles.pharmacyName}>Adam Medic</Text>
                      <Text style={styles.pharmacyAddress}>Daz Street bay zone SC, US</Text>
                    </View>
                  </View>
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default MedicalWallet;

const styles = StyleSheet.create({
  pageTitle: {
    textAlign: 'center',
    fontSize: 22,
    color: '#465D69',
    fontWeight: '500',
    marginBottom: 10,
    marginTop: 10,
  },
  card: {
    backgroundColor: '#E9E7E1',
    borderRadius: 18,
    padding: 16,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  titleBox: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionHeading: {
    color: '#22577A',
    fontSize: 20,
    fontWeight: 'bold',
  },
  detailsContent: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    flexWrap: 'wrap',
  },
  detailLabel: {
    fontWeight: 'bold',
    color: '#22577A',
    marginRight: 6,
  },
  detailValue: {
    color: '#444',
    marginRight: 10,
  },
  bloodGroup: {
    backgroundColor: '#D7F9F1',
    color: '#22577A',
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 2,
    fontSize: 12,
    marginLeft: 8,
  },
  tableHeaderRow: {
    flexDirection: 'row',
    backgroundColor: '#D7F9F1',
    borderRadius: 8,
    paddingVertical: 6,
    marginBottom: 4,
  },
  tableHeader: {
    flex: 1,
    fontWeight: 'bold',
    color: '#22577A',
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 4,
  },
  tableCell: {
    flex: 1,
    color: '#444',
    textAlign: 'center',
  },
  pharmacyRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
  },
  pharmacyCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 10,
    alignItems: 'center',
    width: 120,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 1,
  },
  addPharmacyCard: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#22577A',
    backgroundColor: '#E9E7E1',
  },
  addPharmacyText: {
    fontSize: 36,
    color: '#22577A',
    fontWeight: 'bold',
  },
  pharmacyLogo: {
    width: 40,
    height: 40,
    borderRadius: 8,
    marginBottom: 6,
  },
  pharmacyName: {
    fontWeight: 'bold',
    color: '#22577A',
    fontSize: 15,
    marginBottom: 2,
  },
  pharmacyAddress: {
    color: '#444',
    fontSize: 12,
    textAlign: 'center',
  },
  scrollViewStyles: {
    flex: 1,
  },
  scrollViewStylesInner: { gap: 20, paddingBottom: 20 },
  contentPadding: {
    paddingHorizontal: 18,
  },
  contentSection: {
    paddingHorizontal: 18,
    flex: 1,
  },
  animatedContent: {
    zIndex: 1,
    backgroundColor: 'transparent',
    width: '100%',
  },
  listWrapper: {
    flex: 1,
  },
});
