import {
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Linking,
  Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import TitleText from "../components/TitleText";
import SubText from "../components/SubText";
import SmallButton from "../components/SmallButton";
import ThreeColumnBox from "../components/ThreeColumnBox";
import { useTheme } from "../theme/ThemeContext";
import DetailsCard from "../components/DetailsCard";
import PharmacyList from "../components/PharmacyList";
import Icon from "react-native-vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import AnimatedBackground from "../components/AnimatedBackground";
import { useNavigation } from '@react-navigation/native';
import Header from "../components/Header";

const Sos = () => {
  const { theme } = useTheme();

  const router = useRouter();
  const navigation = useNavigation();

  const handlePress = () => {
   Linking.openURL('tel:911');
  };

  return (
    <AnimatedBackground>
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
          {/* Header Component */}
          <Header 
            profileImage={require("../../assets/user.jpg")}
            greeting="Hello Scott"
            location="SC, 702 USA"
            sos={false}
          />

          {/* SOS Button */}
          <View style={{ alignItems: 'center', marginBottom: 24 }}>
            <TouchableOpacity style={styles.sosBtn} onPress={handlePress}>
              <Icon name="call" size={22} color="#fff" style={{ marginRight: 8 }} />
              <Text style={styles.sosBtnText}>Click here to dial 911</Text>
            </TouchableOpacity>
          </View>
          <View style={{paddingLeft: 16, paddingRight: 16,}}>
          {/* Personal Details */}
          <View style={styles.sectionBox}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Personal Details</Text>
              <TouchableOpacity style={styles.editBtn}><Text style={styles.editBtnText}>Edit</Text></TouchableOpacity>
            </View>
            <View style={styles.cardBox}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <View>
                  <Text style={styles.cardLabel}>Name: <Text style={styles.cardValue}>Scott</Text></Text>
                  <Text style={styles.cardLabel}>Contact No: <Text style={styles.cardValue}>+12134123</Text></Text>
                  <Text style={styles.cardLabel}>Address: <Text style={styles.cardValue}>Park Avenue, Sc US</Text></Text>
                </View>
                <View style={styles.bloodGroupPill}><Text style={styles.bloodGroupText}>Blood Group: O+</Text></View>
              </View>
            </View>
          </View>

          {/* Emergency Details */}
          <View style={styles.sectionBox}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Emergency Details</Text>
              <TouchableOpacity style={styles.editBtn}><Text style={styles.editBtnText}>Edit</Text></TouchableOpacity>
            </View>
            <View style={[styles.cardBox, { padding: 0 }]}>  
              <View style={styles.tableHeaderRow}>
                <Text style={styles.tableHeader}>Name</Text>
                <Text style={styles.tableHeader}>Relation</Text>
                <Text style={styles.tableHeader}>Contact</Text>
              </View>
              <View style={styles.tableRow}><Text style={styles.tableCell}>Alex</Text><Text style={styles.tableCell}>Father</Text><Text style={styles.tableCell}>+12134123</Text></View>
              <View style={styles.tableRow}><Text style={styles.tableCell}>Scott</Text><Text style={styles.tableCell}>Son</Text><Text style={styles.tableCell}>+12134123</Text></View>
              <View style={styles.tableRow}><Text style={styles.tableCell}>Bart</Text><Text style={styles.tableCell}>Friend</Text><Text style={styles.tableCell}>2</Text></View>
            </View>
          </View>

          {/* Doctor Details */}
          <View style={styles.sectionBox}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Doctor Details</Text>
              <TouchableOpacity style={styles.editBtn}><Text style={styles.editBtnText}>Edit</Text></TouchableOpacity>
            </View>
            <View style={styles.cardBox}>
              <Text style={styles.cardLabel}>Doctor Name: <Text style={styles.cardValue}>Scott</Text></Text>
              <Text style={styles.cardLabel}>Phone No: <Text style={styles.cardValue}>+12134123</Text></Text>
              <Text style={styles.cardLabel}>Email- Address: <Text style={styles.cardValue}>Park Avenue, Sc US</Text></Text>
              {/* Progress Dots */}
              <View style={styles.progressDotsRow}>
                <View style={[styles.dot, { backgroundColor: '#fff' }]} />
                <View style={[styles.dot, { backgroundColor: '#e0d6cb' }]} />
                <View style={[styles.dot, { backgroundColor: '#e0d6cb' }]} />
              </View>
            </View>
          </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default Sos;

const styles = StyleSheet.create({
  sosBtn: {
    flexDirection: 'row',
    backgroundColor: '#EB2F29',
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    maxWidth: 200,
    marginBottom: 0,
  },
  sosBtnText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  sectionBox: {
    marginBottom: 28,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  sectionTitle: {
    color: '#000',
    fontSize: 26,
    fontWeight: '400',
  },
  editBtn: {
    backgroundColor: '#e0d6cb',
    borderRadius: 8,
    paddingHorizontal: 18,
    paddingVertical: 4,
  },
  editBtnText: {
    color: '#6b6b6b',
    fontWeight: '600',
    fontSize: 16,
  },
  cardBox: {
    backgroundColor: '#cfd6df',
    borderRadius: 20,
    padding: 18,
    marginTop: 0,
  },
  cardLabel: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 6,
  },
  cardValue: {
    color: '#6b6b6b',
    fontWeight: '400',
    fontSize: 16,
  },
  bloodGroupPill: {
    backgroundColor: '#e0d6cb',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 4,
    alignSelf: 'flex-start',
    marginLeft: 10,
    marginTop: 2,
  },
  bloodGroupText: {
    color: '#6b6b6b',
    fontWeight: '600',
    fontSize: 14,
  },
  tableHeaderRow: {
    flexDirection: 'row',
    backgroundColor: '#e0d6cb',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingVertical: 8,
    paddingHorizontal: 10,
  },
  tableHeader: {
    flex: 1,
    color: '#6b6b6b',
    fontWeight: '600',
    fontSize: 16,
    textAlign: 'left',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderBottomWidth: 0,
  },
  tableCell: {
    flex: 1,
    color: '#6b6b6b',
    fontSize: 16,
    textAlign: 'left',
  },
  progressDotsRow: {
    flexDirection: 'row',
    marginTop: 18,
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 10,
  },
  dot: {
    width: 28,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
});
