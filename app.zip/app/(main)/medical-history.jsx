import { View, Text, StyleSheet, Image, TouchableOpacity, TextInput, ScrollView, Animated, Easing } from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AnimatedBackground from '../components/AnimatedBackground';
import Header from '../components/Header';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState, useRef, useEffect } from 'react';

const profileImg = require('../../assets/user.jpg');

const questions = [
  { id: 1, text: 'What is your age?' },
  { id: 2, text: 'What symptoms are you experiencing?' },
  { id: 3, text: 'What symptoms are you experiencing?' },
  { id: 4, text: 'What symptoms are you experiencing?' },
  { id: 5, text: 'What symptoms are you experiencing?' },
  { id: 6, text: 'What symptoms are you experiencing?' },
  { id: 7, text: 'What symptoms are you experiencing?' },
  { id: 8, text: 'What symptoms are you experiencing?' },
  { id: 9, text: 'What symptoms are you experiencing?' },
  { id: 10, text: 'What symptoms are you experiencing?' },
  { id: 11, text: 'What symptoms are you experiencing?' },
  { id: 12, text: 'What symptoms are you experiencing?' },
  { id: 13, text: 'What symptoms are you experiencing?' },
];

const HEADER_HEIGHT = 380; // Match search-history

const MedicalHistory = () => {
  const { theme } = useTheme();
  const navigation = useNavigation();
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const lastScrollY = useRef(0);
  const anim = useRef(new Animated.Value(0)).current;

  // Animate header in/out
  const animateHeader = (show) => {
    Animated.timing(anim, {
      toValue: show ? 0 : -HEADER_HEIGHT,
      duration: 350,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  };

  // Scroll handler
  const handleScroll = (event) => {
    const currentY = event.nativeEvent.contentOffset.y;
    const delta = currentY - lastScrollY.current;
    if (Math.abs(delta) < 10) return;
    if (delta > 0 && isHeaderVisible && currentY > 40) {
      setIsHeaderVisible(false);
      animateHeader(false);
    } else if (delta < 0 && !isHeaderVisible && currentY < 60) {
      setIsHeaderVisible(true);
      animateHeader(true);
    }
    lastScrollY.current = currentY;
  };

  return (
    <AnimatedBackground>
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.contentSection}>
          <Animated.View
            style={[
              styles.animatedContent,
              {
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                marginLeft: "5%",
                transform: [{ translateY: anim }],
                opacity: anim.interpolate({
                  inputRange: [-HEADER_HEIGHT, 0],
                  outputRange: [0, 1],
                }),
              },
            ]}
          >
            <Header
              profileImage={profileImg}
              greeting="Hello Scott"
              location="SC, 702 USA"
              sos={true}
            />
            <Text style={styles.title}>Medical History</Text>
            <View style={styles.searchBarWrapper}>
              <TextInput
                style={styles.searchBar}
                placeholder="Search your chat"
                placeholderTextColor="#7c7c7c"
              />
            </View>
          </Animated.View>
          <View style={styles.listWrapper}>
            <ScrollView
              contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_HEIGHT }]}
              showsVerticalScrollIndicator={false}
              onScroll={handleScroll}
              scrollEventThrottle={16}
              style={styles.scrollView}
            >
              {questions.map((q, idx) => (
                <View key={q.id} style={styles.card}>
                  <Ionicons name="checkmark-done-circle-outline" size={28} color="#00FF57" style={styles.checkIcon} />
                  <Text style={styles.cardText}>{q.text.length > 30 ? q.text.slice(0, 30) + '...' : q.text}</Text>
                  <TouchableOpacity style={styles.editBtn}>
                    <Text style={styles.editText}>Edit</Text>
                  </TouchableOpacity>
                </View>
              ))}
            </ScrollView>
          </View>
        </View>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default MedicalHistory;

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  title: {
    fontSize: 36,
    color: '#4d5a5a',
    textAlign: 'center',
    fontWeight: '400',
    marginBottom: 18,
  },
  contentSection: {
    paddingHorizontal: 18,
    flex: 1,
  },
  animatedContent: {
    zIndex: 1,
    backgroundColor: 'transparent',
    width: '100%',
  },
  searchBarWrapper: {
    width: '90%',
    marginBottom: 18,
    backgroundColor: '#e5e8de',
    borderRadius: 28,
    paddingHorizontal: 18,
    paddingVertical: 6,
    marginLeft:"5%"
  },
  searchBar: {
    fontSize: 20,
    color: '#4d5a5a',
    paddingVertical: 8,
    backgroundColor: 'transparent',
  },
  listWrapper: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#d3cdc3',
    borderRadius: 32,
    paddingVertical: 22,
    paddingHorizontal: 18,
    width: '100%',
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
  },
  checkIcon: { marginRight: 12 },
  cardText: {
    flex: 1,
    fontSize: 20,
    color: '#222',
    fontWeight: '500',
  },
  editBtn: {
    paddingHorizontal: 10,
    paddingVertical: 2,
  },
  editText: {
    color: '#222',
    fontSize: 18,
    fontWeight: '600',
  },
}); 