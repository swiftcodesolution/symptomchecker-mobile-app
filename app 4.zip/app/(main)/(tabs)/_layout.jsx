import { Tabs } from "expo-router";
import Icon from "react-native-vector-icons/Ionicons";
import Icon2 from "react-native-vector-icons/SimpleLineIcons";
import { useTheme } from "../../theme/ThemeContext";
import { Image } from "react-native";

const TabLayout = () => {
  const { theme } = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#E6E3D9',
        tabBarInactiveTintColor: '#444846',
        tabBarStyle: {
          backgroundColor: '#9EA18D',
          borderTopWidth: 0,
          height: 70,
        },
        tabBarLabelStyle: {
          fontFamily: 'Avenir',
          fontSize: 8,
          letterSpacing: 1,
          marginBottom: 4,
        },
      }}
    >
      <Tabs.Screen
        name="home"
        options={{
          title: "Home",
          tabBarIcon: ({ color }) => (
            <Image
              source={require("../../../assets/menu-icons/home.png")}
              style={{ tintColor: color, width: 17, height: 17, marginBottom: 2 }}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="index"
        options={{
          title: "Symptom Checker",
          tabBarIcon: ({ color }) => (
            <Image
              source={require("../../../assets/menu-icons/card1.png")}
              style={{ tintColor: color, width: 17, height: 17, marginBottom: 2 }}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="medical-cabinet"
        options={{
          title: "Medical Cabinet",
          tabBarIcon: ({ color }) => (
            <Image
              source={require("../../../assets/menu-icons/medical-cabinet.png")}
              style={{ tintColor: color, width: 17, height: 17, marginBottom: 2 }}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="medical-wallet"
        options={{
          title: "Medical Wallet",
          tabBarIcon: ({ color }) => (
            <Image
              source={require("../../../assets/menu-icons/medical-wallet.png")}
              style={{ tintColor: color, width: 17, height: 17, marginBottom: 2 }}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="medical-library"
        options={{
          title: "Medical Library",
          tabBarIcon: ({ color }) => (
            <Image
              source={require("../../../assets/menu-icons/medical-library.png")}
              style={{ tintColor: color, width: 17, height: 17, marginBottom: 2 }}
            />
          ),
        }}
      />
    </Tabs>
  );
};

export default TabLayout;
