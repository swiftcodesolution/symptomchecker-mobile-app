"use client"

import { useEffect, useState, useRef, useCallback } from "react"
import AsyncStorage from "@react-native-async-storage/async-storage"
import PrimaryButton from "../../components/PrimaryButton"
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useTheme } from "../../theme/ThemeContext"
import Icon from "react-native-vector-icons/Feather"
import { useNavigation, useFocusEffect } from "@react-navigation/native"
import AnimatedBackground from "../../components/AnimatedBackground"
import Header from "../../components/Header"
import AnimatedSoundWaves from "../../components/AnimatedSoundWaves"
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from "expo-speech-recognition"
import * as Speech from "expo-speech"
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { saveBlockToFirebase } from "../../utils/firebaseUtils"


const profileImg = require("../../../assets/user.jpg")

const DISCLOSURE_KEY = "symptomCheckerDisclosureAgreed"
const OPENAI_API_KEY = "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"

const disclosureText = [
  "Before You Begin",
  "The Symptom Checker provides general health insights based on AI and your health inputs. It is not a substitute for medical advice, and it is not a medical device.",
  "For diagnosis or treatment, please consult a licensed medical professional.",
  "By using this tool, you acknowledge and agree to these terms.",
  "Important Information About the Symptom Checker",
  "The Symptom Checker feature in Your Health Companion is designed to provide informational insights only. It uses advanced AI and your personal health data to help you better understand potential causes of your symptoms.",
  "However, it is not a substitute for professional medical advice, diagnosis, or treatment.",
  "This feature is not a medical device and is not intended to make medical decisions on your behalf.",
  "We strongly recommend that you consult with a licensed healthcare provider for any health concerns.",
  "Always seek the guidance of a qualified professional before acting on any information provided here.",
  '"Think of this tool as a helpful companion—not a doctor. It gives you smart insights to prepare you for a real conversation with your healthcare provider."',
]

const predefinedResponses = {
  "how are you": "I am fine, thank you for asking.",
  default: "Currently, we don't have Open AI integrated, so you can't ask too many questions right now.",
}

const Home = () => {
  const { theme } = useTheme()
  const navigation = useNavigation()
  const [showDisclosure, setShowDisclosure] = useState(false)
  const [messages, setMessages] = useState([])
  const [inputText, setInputText] = useState("")
  const [voiceInputText, setVoiceInputText] = useState("")
  const [chatStarted, setChatStarted] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [recognizedText, setRecognizedText] = useState("")
  const [recognizing, setRecognizing] = useState(false)
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState(null)
  const [isSpeaking, setIsSpeaking] = useState(false) // New state for speech status
  const [isLoading, setIsLoading] = useState(false)
  const scrollViewRef = useRef()
  const [processingEndEvent, setProcessingEndEvent] = useState(false)

  // Speech recognition event handlers
  useSpeechRecognitionEvent("start", () => {
    setRecognizing(true)
    setIsListening(true)
    setVoiceInputText("")
  })

  useSpeechRecognitionEvent("end", () => {
    if (processingEndEvent) return
    setProcessingEndEvent(true)
    setRecognizing(false)
    setIsListening(false)

    setTimeout(() => {
      setProcessingEndEvent(false)
    }, 1000)
  })

  useSpeechRecognitionEvent("result", (event) => {
    if (event.results && event.results[0]) {
      const newTranscript = event.results[0]?.transcript
      setVoiceInputText(newTranscript)
      setRecognizedText(newTranscript)
    }
  })

  useSpeechRecognitionEvent("error", (event) => {
    console.log("error code:", event.error, "error message:", event.message)
    setIsListening(false)
    setRecognizing(false)
  })

  // Function to stop voice recognition safely
  const stopVoiceRecognition = useCallback(async () => {
    try {
      if (isListening || recognizing) {
        if (ExpoSpeechRecognitionModule && ExpoSpeechRecognitionModule.stop) {
          await ExpoSpeechRecognitionModule.stop()
        }
        setIsListening(false)
        setRecognizing(false)
        setVoiceInputText("")
        setRecognizedText("")
      }
      if (currentlySpeakingId || isSpeaking) {
        Speech.stop()
        setCurrentlySpeakingId(null)
        setIsSpeaking(false)
      }
    } catch (error) {
      console.error("Error stopping voice recognition:", error)
    }
  }, [isListening, recognizing, currentlySpeakingId, isSpeaking])

  // Handle screen focus/blur - stop voice when navigating away
  useFocusEffect(
    useCallback(() => {
      // When screen comes into focus, do nothing special
      return () => {
        // When screen loses focus (user navigates to another tab), stop voice
        stopVoiceRecognition()
      }
    }, [stopVoiceRecognition]),
  )

  useEffect(() => {
    const checkDisclosure = async () => {
      const agreed = await AsyncStorage.getItem(DISCLOSURE_KEY)
      if (!agreed) setShowDisclosure(true)
    }
    checkDisclosure()
  }, [])

  // Cleanup effect to stop voice recognition when component unmounts
  useEffect(() => {
    return () => {
      stopVoiceRecognition()
    }
  }, [stopVoiceRecognition])

  const handleAgree = async () => {
    await AsyncStorage.setItem(DISCLOSURE_KEY, "true")
    setShowDisclosure(false)
  }

  const startListening = async () => {
    try {
      const { status } = await ExpoSpeechRecognitionModule.requestPermissionsAsync()
      if (status !== "granted") {
        Alert.alert("Permission required", "Microphone permission is needed for voice recognition")
        return
      }

      ExpoSpeechRecognitionModule.start({
        lang: "en-US",
        interimResults: true,
        continuous: true,
      })
    } catch (error) {
      console.error("Failed to start listening:", error)
      setIsListening(false)
    }
  }

  const stopListening = async () => {
    try {
      await ExpoSpeechRecognitionModule.stop()
      setRecognizedText("")
      // Auto send message when stopping
      if (voiceInputText.trim()) {
        handleSendMessage(voiceInputText, true)
      }
    } catch (error) {
      console.error("Failed to stop listening:", error)
    }
  }

  const handleSendMessage = async (text = inputText, isFromVoice = false) => {
    const messageText = isFromVoice ? voiceInputText : text
    if (messageText.trim() === "" || messages.some((msg) => msg.text === messageText && msg.isUser)) return

    if (!chatStarted) {
      setChatStarted(true)
    }

    // Create and add user message
    const userMessage = {
      id: Date.now(),
      text: messageText,
      isUser: true,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isFromVoice: isFromVoice,
    }

    setMessages((prev) => [...prev, userMessage])
    setInputText("")
    setVoiceInputText("")
    setRecognizedText("")

    try {
      // Get AI response
      const aiResponseText = await getAIResponse(messageText)

      // Create AI response message
      const aiResponse = {
        id: Date.now() + 1,
        text: aiResponseText,
        isUser: false,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }

      // Add AI response to messages
      setMessages((prev) => [...prev, aiResponse])

      if (aiResponseText.length > 20) { // Only save meaningful responses
        await saveBlockToFirebase({
          title: `AI Response to: ${messageText.substring(0, 30)}...`,
          content: aiResponseText,
          category: "AI Generated",
          isAIGenerated: true,
          originalQuery: messageText,
        });
      }

      // Speak the response if it came from voice
      if (isFromVoice) {
        setCurrentlySpeakingId(aiResponse.id)
        setIsSpeaking(true)

        await Speech.speak(aiResponseText, {
          language: "en",
          rate: 0.9,
          pitch: 1.0,
          onStart: () => {
            setCurrentlySpeakingId(aiResponse.id)
            setIsSpeaking(true)
          },
          onDone: () => {
            setCurrentlySpeakingId(null)
            setIsSpeaking(false)
          },
          onStopped: () => {
            setCurrentlySpeakingId(null)
            setIsSpeaking(false)
          },
        })
      }
    } catch (error) {
      console.error("Error in handleSendMessage:", error)
      // Add error message to chat
      const errorMessage = {
        id: Date.now() + 1,
        text: "Sorry, I encountered an error processing your request.",
        isUser: false,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }
      setMessages((prev) => [...prev, errorMessage])
    }
  }

  const getAIResponse = async (userInput) => {
    setIsLoading(true)
    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: [
            {
              role: "system",
              content: "You are a helpful medical assistant. Provide concise, accurate health information but always remind users to consult with a real doctor for medical advice. Keep responses under 100 words.",
            },
            {
              role: "user",
              content: userInput,
            },
          ],
          temperature: 0.7,
          max_tokens: 150,
        }),
      })

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`)
      }

      const data = await response.json()
      return data.choices[0]?.message?.content || "I couldn't process your request. Please try again."
    } catch (error) {
      console.error("Error calling OpenAI API:", error)
      return "Sorry, I'm having trouble connecting to the service. Please try again later."
    } finally {
      setIsLoading(false)
    }
  }

  const handleVoiceButtonPress = async () => {
    // Don't allow voice input while AI is speaking
    if (isSpeaking) {
      Alert.alert("Please wait", "AI is currently speaking. Please wait for it to finish.")
      return
    }

    if (isListening) {
      // If currently listening, stop and send message
      await stopListening()
    } else {
      // If not listening, start listening
      await startListening()
      setInputText("")
    }
  }

  // Check if voice button should be disabled
  const isVoiceButtonDisabled = isSpeaking || isLoading

  return (
    <>
      <Modal visible={showDisclosure} transparent animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <ScrollView contentContainerStyle={styles.modalScroll} showsVerticalScrollIndicator={false}>
              {disclosureText.map((line, idx) => (
                <Text key={idx} style={idx === 0 ? styles.modalTitle : styles.modalText}>
                  {line}
                </Text>
              ))}
              <PrimaryButton
                title="Agree & Continue"
                pressFunction={handleAgree}
                style={styles.agreeButton}
                textColor="#fff"
              />
            </ScrollView>
          </View>
        </View>
      </Modal>

      <AnimatedBackground>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 0 : -10}
        >
          <SafeAreaView style={styles.container}>
            <ScrollView
              contentContainerStyle={styles.scrollContent}
              showsVerticalScrollIndicator={false}
              ref={scrollViewRef}
              onContentSizeChange={() => scrollViewRef.current?.scrollToEnd({ animated: true })}
            >
              {!chatStarted && (
                <Header profileImage={profileImg} greeting="Hello Scott" location="SC, 702 USA" sos={true} />
              )}

              <View style={styles.chatContainer}>
                {messages.map((message) => (
                  <View
                    key={message.id}
                    style={[
                      styles.messageBubble,
                      message.isUser ? styles.userBubble : styles.aiBubble,
                      currentlySpeakingId === message.id && styles.speakingBubble,
                      message.isFromVoice && styles.voiceMessageIndicator,
                    ]}
                  >
                    {message.isFromVoice && !message.isUser && (
                      <View style={styles.voiceIconContainer}>
                        <Icon name="volume-2" size={16} color="#6B705B" />
                      </View>
                    )}
                    <Text style={message.isUser ? styles.userText : styles.aiText}>{message.text}</Text>
                    <Text style={message.isUser ? styles.userTime : styles.aiTime}>{message.time}</Text>
                  </View>
                ))}
                {isLoading && (
                  <View style={[styles.messageBubble, styles.aiBubble]}>
                    <Text style={styles.aiText}>Thinking...</Text>
                  </View>
                )}
              </View>

              <View style={styles.centerCheckWrapper}>
                {isListening ? (
                  <View style={styles.voiceControlsContainer}>
                    <TouchableOpacity
                      style={[styles.voiceControlBtn, styles.pauseBtn, isVoiceButtonDisabled && styles.disabledBtn]}
                      onPress={handleVoiceButtonPress}
                      disabled={isVoiceButtonDisabled}
                    >
                      <Icon name="pause" size={40} color={isVoiceButtonDisabled ? "#999" : "#FF0000"} />
                      <Text style={[styles.pauseText, isVoiceButtonDisabled && styles.disabledText]}>
                        {isVoiceButtonDisabled ? "AI Speaking..." : "Tap to Send"}
                      </Text>
                    </TouchableOpacity>

                    {/* <View style={styles.soundWaveContainer}>
                      <AnimatedSoundWaves isActive={recognizing && !isVoiceButtonDisabled} color="#6B705B" />
                      <Text style={styles.listeningText}>
                        {isVoiceButtonDisabled ? "AI is speaking..." : "Listening..."}
                      </Text>
                    </View> */}
                  </View>
                ) : (
                  <TouchableOpacity
                    style={[styles.checkBtn, isVoiceButtonDisabled && styles.disabledBtn]}
                    onPress={handleVoiceButtonPress}
                    disabled={isVoiceButtonDisabled}
                  >
                    <Icon name="mic" size={40} color={isVoiceButtonDisabled ? "#999" : "#6B705B"} />
                    <Text style={[styles.startListeningText, isVoiceButtonDisabled && styles.disabledText]}>
                      {isVoiceButtonDisabled ? (isLoading ? "Thinking..." : "AI Speaking...") : "Tap to Speak"}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            </ScrollView>

            {isListening && !isVoiceButtonDisabled && (
              <View style={styles.voiceInputContainer}>
                <Text style={styles.voiceInputText}>{voiceInputText || "Listening..."}</Text>
              </View>
            )}

            {!isListening && (
              <View style={styles.inputBoxWrapper}>
                <View style={[styles.inputBox, { backgroundColor: theme.onboardingCardBg || "#E9E7E1" }]}>
                  <TextInput
                    style={styles.input}
                    placeholder="Ask Symptom Checker..."
                    placeholderTextColor="#465D69"
                    value={inputText}
                    onChangeText={setInputText}
                    editable={!isVoiceButtonDisabled} // Disable text input when AI is speaking
                  />
                  <TouchableOpacity
                    style={[styles.sendBtn, isVoiceButtonDisabled && styles.disabledSendBtn]}
                    onPress={() => {
                      if (inputText.trim() && !isVoiceButtonDisabled) {
                        handleSendMessage(inputText, false)
                      }
                    }}
                    disabled={isVoiceButtonDisabled}
                  >
                    <Icon name="send" size={24} color={isVoiceButtonDisabled ? "#999" : "#fff"} />
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </SafeAreaView>
        </KeyboardAvoidingView>
      </AnimatedBackground>
    </>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 0,
    justifyContent: "flex-start",
  },
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.7)",
    justifyContent: "flex-end",
    alignItems: "center",
  },
  modalContent: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    width: "100%",
    maxWidth: 500,
    minHeight: 420,
    elevation: 8,
  },
  modalScroll: {
    paddingBottom: 24,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 10,
    color: "#222",
    textAlign: "left",
  },
  modalText: {
    fontSize: 16,
    marginBottom: 10,
    color: "#222",
    textAlign: "left",
  },
  agreeButton: {
    backgroundColor: "#6B705B",
    marginTop: 18,
  },
  centerCheckWrapper: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },
  checkBtn: {
    backgroundColor: "#E9E7E1",
    borderRadius: 100,
    padding: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  disabledBtn: {
    backgroundColor: "#D3D3D3",
    shadowOpacity: 0.05,
    elevation: 2,
  },
  voiceControlsContainer: {
    alignItems: "center",
    gap: 20,
  },
  voiceControlBtn: {
    backgroundColor: "#E9E7E1",
    borderRadius: 100,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  pauseBtn: {
    backgroundColor: "#FFEEEE",
  },
  pauseText: {
    color: "#FF0000",
    fontSize: 14,
    marginTop: 8,
  },
  startListeningText: {
    color: "#6B705B",
    fontSize: 14,
    marginTop: 8,
  },
  disabledText: {
    color: "#999",
  },
  listeningText: {
    marginTop: 8,
    color: "#6B705B",
    fontSize: 14,
    textAlign: "center",
  },
  soundWaveContainer: {
    backgroundColor: "#F5F5F5",
    borderRadius: 20,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
    alignItems: "center",
  },
  chatContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
    flex: 1,
  },
  messageBubble: {
    maxWidth: "80%",
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
    position: "relative",
  },
  userBubble: {
    alignSelf: "flex-end",
    backgroundColor: "#6B705B",
    borderBottomRightRadius: 0,
  },
  aiBubble: {
    alignSelf: "flex-start",
    backgroundColor: "#E9E7E1",
    borderBottomLeftRadius: 0,
  },
  speakingBubble: {
    borderWidth: 2,
    borderColor: "#6B705B",
  },
  voiceMessageIndicator: {
    borderLeftWidth: 3,
    borderLeftColor: "#6B705B",
  },
  voiceIconContainer: {
    position: "absolute",
    left: 8,
    top: 8,
  },
  userText: {
    color: "#fff",
    fontSize: 16,
  },
  aiText: {
    color: "#465D69",
    fontSize: 16,
  },
  userTime: {
    color: "#E9E7E1",
    fontSize: 12,
    textAlign: "right",
    marginTop: 4,
  },
  aiTime: {
    color: "#888",
    fontSize: 12,
    textAlign: "left",
    marginTop: 4,
  },
  inputBoxWrapper: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  inputBox: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
    borderRadius: 32,
    marginTop: 10,
  },
  input: {
    fontSize: 18,
    flex: 1,
    color: "#465D69",
  },
  sendBtn: {
    backgroundColor: "#6B705B",
    padding: 12,
    borderRadius: 100,
    marginLeft: 10,
  },
  disabledSendBtn: {
    backgroundColor: "#D3D3D3",
  },
  voiceInputContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: "#E9E7E1",
    marginHorizontal: 20,
    borderRadius: 32,
    marginBottom: 30,
  },
  voiceInputText: {
    flex: 1,
    fontSize: 16,
    color: "#465D69",
    paddingHorizontal: 10,
  },
})

export default Home
