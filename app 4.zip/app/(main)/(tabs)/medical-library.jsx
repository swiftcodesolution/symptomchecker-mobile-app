import { FlatList, StyleSheet, Text, View, Animated, Easing } from "react-native";
import { useTheme } from "../../theme/ThemeContext";
import { SafeAreaView } from "react-native-safe-area-context";
import CustomHeader from "../../components/CustomHeader";
import TitleText from "../../components/TitleText";
import Searchbar from "../../components/Searchbar";
import LibraryCard from "../../components/LibraryCard";
import AnimatedBackground from "../../components/AnimatedBackground";
import Header from "../../components/Header";
import { useState, useRef, useEffect } from "react";
import { getBlocksFromFirebase } from "../../utils/firebaseUtils";

const profileImg = require("../../../assets/user.jpg");

const defaultLibraryCards = [
  {
    id: "1",
    imageUrl: require("../../../assets/cover.jpg"),
    text: "Understanding Common Cold vs Flu",
    tag: "General Health",
    date: "2025-06-01",
    shareLink: "Share Symptoms",
  },
  {
    id: "2",
    imageUrl: require("../../../assets/cover.jpg"),
    text: "AI Insights: Headache Patterns",
    tag: "Neurology",
    date: "2025-05-28",
    shareLink: "Share Report",
  },
  {
    id: "3",
    imageUrl: require("../../../assets/cover.jpg"),
    text: "When to Worry About a Cough",
    tag: "Respiratory",
    date: "2025-06-03",
    shareLink: "Share Advice",
  },
  {
    id: "4",
    imageUrl: require("../../../assets/cover.jpg"),
    text: "Tracking Abdominal Pain with AI",
    tag: "Gastroenterology",
    date: "2025-06-05",
    shareLink: "Share Check",
  },
  {
    id: "5",
    imageUrl: require("../../../assets/cover.jpg"),
    text: "Skin Rashes: Image-Based Diagnosis",
    tag: "Dermatology",
    date: "2025-05-30",
    shareLink: "Share Image",
  },
  {
    id: "6",
    imageUrl: require("../../../assets/cover.jpg"),
    text: "AI for Mental Health: Symptom Tracker",
    tag: "Mental Health",
    date: "2025-06-02",
    shareLink: "Share Insights",
  },
];

const HEADER_HEIGHT = 400; // Match search-history

const MedicalLibrary = () => {
  const { theme } = useTheme();
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const [libraryCards, setLibraryCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const lastScrollY = useRef(0);
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const fetchBlocks = async () => {
      try {
        const blocks = await getBlocksFromFirebase();
        const formattedBlocks = blocks.map(block => ({
          id: block.id,
          imageUrl: require("../../../assets/cover.jpg"),
          text: block.title || "AI Generated Response",
          tag: block.category || "AI Generated",
          date: new Date(block.createdAt).toISOString().split('T')[0],
          shareLink: "View Details",
          content: block.content,
          isAIGenerated: block.isAIGenerated || false,
        }));
        
        setLibraryCards(formattedBlocks);
      } catch (error) {
        console.error("Error fetching blocks:", error);
        setLibraryCards(defaultLibraryCards);
      } finally {
        setLoading(false);
      }
    };
  
    fetchBlocks();
  }, []);

  // Animate header in/out
  const animateHeader = (show) => {
    Animated.timing(anim, {
      toValue: show ? 0 : -HEADER_HEIGHT,
      duration: 350,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  };

  // Scroll handler
  const handleScroll = (event) => {
    const currentY = event.nativeEvent.contentOffset.y;
    const delta = currentY - lastScrollY.current;
    if (Math.abs(delta) < 10) return;
    if (delta > 0 && isHeaderVisible && currentY > 40) {
      setIsHeaderVisible(false);
      animateHeader(false);
    } else if (delta < 0 && !isHeaderVisible && currentY < 60) {
      setIsHeaderVisible(true);
      animateHeader(true);
    }
    lastScrollY.current = currentY;
  };

  return (
    <AnimatedBackground>
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.contentSection}>
          <Animated.View
            style={[
              styles.animatedContent,
              {
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                marginLeft: "5%",
                transform: [{ translateY: anim }],
                opacity: anim.interpolate({
                  inputRange: [-HEADER_HEIGHT, 0],
                  outputRange: [0, 1],
                }),
              },
            ]}
          >
            <Header
              profileImage={profileImg}
              greeting="Hello Scott"
              location="SC, 702 USA"
              sos={true}
            />
            <TitleText title="Medical Library" style={styles.pageTitle} />
            <Searchbar />
          </Animated.View>
          <View style={styles.listWrapper}>
            <FlatList
              data={libraryCards}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <LibraryCard
                  imageUrl={item.imageUrl}
                  text={item.text}
                  tag={item.tag}
                  date={item.date}
                  shareLink={item.shareLink}
                />
              )}
              contentContainerStyle={[styles.libraryListInner, { paddingTop: HEADER_HEIGHT }]}
              onScroll={handleScroll}
              scrollEventThrottle={16}
              showsVerticalScrollIndicator={false}
              style={styles.flatList}
            />
          </View>
        </View>
      </SafeAreaView>
    </AnimatedBackground>
  );
};

export default MedicalLibrary;

const styles = StyleSheet.create({
  contentSection: {
    paddingHorizontal: 18,
    flex: 1,
  },
  animatedContent: {
    zIndex: 1,
    backgroundColor: 'transparent',
    width: '100%',
  },
  listWrapper: {
    flex: 1,
  },
  flatList: {
    flex: 1,
  },

  pageTitle: { textAlign: "center", marginTop: 0, marginBottom: 20 },

  libraryListInner: { gap: 20, paddingBottom: 20, paddingHorizontal: 18 },
});
