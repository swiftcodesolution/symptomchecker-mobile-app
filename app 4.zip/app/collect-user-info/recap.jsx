"use client"

import { StyleSheet, View, ScrollView, Text, ActivityIndicator } from "react-native"
import RecapCard from "../components/RecapCard"
import { questionsData } from "./index"
import { SafeAreaView } from "react-native-safe-area-context"
import { useTheme } from "../theme/ThemeContext"
import TitleText from "../components/TitleText"
import SubText from "../components/SubText"
import PrimaryButton from "../components/PrimaryButton"
import { useRouter } from "expo-router"
import AnimatedBackground from "../components/AnimatedBackground"
import AsyncStorage from "@react-native-async-storage/async-storage"
import { useState, useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import { selectAnswers } from "../redux/slices/userInfoSlice"
import { setCurrentIndex } from "../redux/slices/userInfoSlice"
import { firebaseAuth, firestore } from "../config/firebase"
import { doc, setDoc } from "firebase/firestore"
import { toast } from "sonner-native"

const Recap = () => {
  const { theme } = useTheme()
  const router = useRouter()
  const [userAnswers, setUserAnswers] = useState({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const answerss = useSelector(selectAnswers)
  const dispatch = useDispatch()

  useEffect(() => {
    const loadUserAnswers = async () => {
      try {
        const savedAnswers = await AsyncStorage.getItem("userPersonalInfo")
        if (savedAnswers) {
          setUserAnswers(JSON.parse(savedAnswers))
        }
      } catch (error) {
        console.error("Error loading user answers:", error)
      } finally {
        setLoading(false)
      }
    }
    loadUserAnswers()
  }, [])

  // Create answers array based on actual user data
  const answers = questionsData.map((question, index) => {
    const answerItem = answerss[index] || {}
    return {
      question: answerItem.answer,
      hasAnswer: !!answerItem.answer && answerItem.answer.trim() !== "",
      answer: answerItem.answer || "",
      summarizedAnswer: answerItem.summarizedAnswer || "",
    }
  })

  const editAnswer = (index) => {
    dispatch(setCurrentIndex(index))
    // Pass edit parameter to indicate edit mode
    router.push(`/collect-user-info?edit=true`)
  }

  const handleDone = async () => {
    try {
      setSaving(true)

      // Optimistic UI - navigate immediately
      toast("Saving your information...")

      // Navigate first for better UX
      router.push("/(main)")

      // Save in background
      setTimeout(async () => {
        try {
          // Get current authenticated user
          const user = firebaseAuth.currentUser
          if (!user) {
            throw new Error("User not authenticated")
          }

          const cleanedAnswers = answerss.map((answer) => ({
            answer: answer?.answer || "",
            summarizedAnswer: answer?.summarizedAnswer || "",
          }))

          const hasEmptyAnswers = cleanedAnswers.some((item) => !item.answer.trim())
          if (hasEmptyAnswers) {
            throw new Error("Please fill all required fields")
          }

          // Prepare data for Firestore
          const userData = {
            answers: cleanedAnswers,
            completedAt: new Date().toISOString(),
            userId: user.uid,
            email: user.email || "",
          }

          // Save to Firestore in background
          const userDocRef = doc(firestore, "users", user.uid)
          await setDoc(userDocRef, userData, { merge: true })

          // Mark as completed in AsyncStorage
          await AsyncStorage.setItem("personalInfo", "completed")

          toast("Your information has been saved successfully!")
        } catch (error) {
          console.error("Error saving personal info:", error)
          toast("Failed to save your information. We'll retry automatically.")

          // Retry logic - save to local storage for later sync
          try {
            const retryData = {
              answers: answerss,
              timestamp: new Date().toISOString(),
              needsSync: true,
            }
            await AsyncStorage.setItem("pendingUserData", JSON.stringify(retryData))
          } catch (localError) {
            console.error("Failed to save locally:", localError)
          }
        } finally {
          setSaving(false)
        }
      }, 100) // Small delay to ensure navigation happens first
    } catch (error) {
      console.error("Error in handleDone:", error)
      toast("An error occurred. Please try again.")
      setSaving(false)
    }
  }

  return (
    <AnimatedBackground>
      <SafeAreaView style={[styles.container, { backgroundColor: "transparent" }]}>
        <View>
          <TitleText style={styles.title} title="Recap" />
          <SubText
            style={styles.text}
            textContent="Thank you for providing your medical details. Please review them and make any necessary corrections."
          />
        </View>

        <ScrollView style={styles.scrollView} contentContainerStyle={{ gap: 18 }}>
          <View style={styles.recapCards}>
            {answers.map((item, index) => (
              <RecapCard
                key={index}
                question={item.question}
                hasAnswer={item.hasAnswer}
                editAnswer={() => editAnswer(index)}
                buttonLabel={item.hasAnswer ? "Edit" : "Reply"}
              />
            ))}
          </View>
        </ScrollView>

        <View>
          {saving ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#6B705B" />
              <Text style={styles.savingText}>Saving in background...</Text>
            </View>
          ) : (
            <PrimaryButton
              title="Done"
              pressFunction={handleDone}
              style={[styles.emailBtn, { backgroundColor: theme.primaryBtnBg }]}
              disabled={saving}
            />
          )}
        </View>
      </SafeAreaView>
    </AnimatedBackground>
  )
}

export default Recap

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", gap: 40, padding: 20 },
  title: { textAlign: "center", marginBottom: 20 },
  text: { textAlign: "center", marginBottom: 0 },
  scrollView: {},
  recapCards: { gap: 18, marginVertical: 20 },
  savingText: {
    textAlign: "center",
    color: "#6B705B",
    fontSize: 12,
    marginTop: 8,
    fontStyle: "italic",
  },
})
