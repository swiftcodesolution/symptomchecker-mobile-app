import { firestore as db } from '../config/firebase';
import { collection, addDoc, getDocs, orderBy, query } from "firebase/firestore"; 

export const saveBlockToFirebase = async (blockData) => {
  try {
    const docRef = await addDoc(collection(db, "medicalBlocks"), {
      ...blockData,
      createdAt: new Date().toISOString(),
    });
    console.log('Block saved with ID: ', docRef.id);
    return docRef.id;
  } catch (error) {
    console.error('Error saving block: ', error);
    throw error;
  }
};

export const getBlocksFromFirebase = async () => {
  try {
    const q = query(
      collection(db, "medicalBlocks"), 
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Error getting blocks: ', error);
    throw error;
  }
};