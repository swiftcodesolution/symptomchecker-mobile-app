// utils/notificationUtils.js
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

// Configure notifications
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

// Request permissions
export const registerForPushNotificationsAsync = async () => {
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  
  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  
  if (finalStatus !== 'granted') {
    alert('Failed to get push token for push notification!');
    return false;
  }
  
  return true;
};

// Parse time string to hours and minutes
const parseTimeString = (timeString) => {
  const [time, period] = timeString.split(' ');
  let [hours, minutes] = time.split(':').map(Number);
  
  // Convert to 24-hour format
  if (period === 'PM' && hours < 12) hours += 12;
  if (period === 'AM' && hours === 12) hours = 0;
  
  return { hours, minutes };
};

// Schedule a notification
export const schedulePushNotification = async (id, title, body, timeString) => {
  try {
    const { hours, minutes } = parseTimeString(timeString);
    
    await Notifications.scheduleNotificationAsync({
      identifier: `medicine-${id}`,
      content: {
        title,
        body,
        sound: 'default',
        data: { medicineId: id },
      },
      trigger: {
        hour: hours,
        minute: minutes,
        repeats: true, // Repeat daily
      },
    });
    
    console.log(`Scheduled notification for ${title} at ${timeString}`);
    return true;
  } catch (error) {
    console.error('Error scheduling notification:', error);
    return false;
  }
};

// Cancel a scheduled notification
export const cancelScheduledNotification = async (id) => {
  try {
    await Notifications.cancelScheduledNotificationAsync(`medicine-${id}`);
    console.log(`Cancelled notification for medicine ${id}`);
    return true;
  } catch (error) {
    console.error('Error cancelling notification:', error);
    return false;
  }
};

// Cancel all notifications
export const cancelAllNotifications = async () => {
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    console.log('Cancelled all scheduled notifications');
    return true;
  } catch (error) {
    console.error('Error cancelling all notifications:', error);
    return false;
  }
};