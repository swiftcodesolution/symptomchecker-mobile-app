import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    answers: Array(3).fill(null).map(() => ({
        answer: "",
        summarizedAnswer: ""
    })),
    currentQuestionIndex: 0,
    isListening: false,
    transcript: '',
};

export const userInfoSlice = createSlice({
    name: 'userInfo',
    initialState,
    reducers: {
        setAnswer: (state, action) => {
            const { index, answer, summarizedAnswer } = action.payload;
            const newAnswers = [...state.answers];
            newAnswers[index] = {
                answer: answer,
                summarizedAnswer: summarizedAnswer || 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
            };
            state.answers = newAnswers;
        },
        setCurrentIndex: (state, action) => {
            state.currentQuestionIndex = action.payload;
        },
        setIsListening: (state, action) => {
            state.isListening = action.payload;
        },
        setTranscript: (state, action) => {
            state.transcript = action.payload;
        },
        resetUserInfo: () => initialState,
    },
});

export const {
    setAnswer,
    setCurrentIndex,
    setIsListening,
    setTranscript,
    resetUserInfo
} = userInfoSlice.actions;

export const selectAnswers = (state) => state.userInfo.answers;
export const selectCurrentIndex = (state) => state.userInfo.currentQuestionIndex;
export const selectIsListening = (state) => state.userInfo.isListening;
export const selectTranscript = (state) => state.userInfo.transcript;

export default userInfoSlice.reducer;